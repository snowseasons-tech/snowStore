"""Internal MVP. Replace create_all with Alembic and HTTP Basic with SSO before public launch."""
import os
import secrets
from contextlib import asynccontextmanager
from datetime import date, datetime, timezone
from pathlib import Path
from typing import Literal

import httpx
from fastapi import Depends, FastAPI, HTTPException, status
from fastapi.responses import FileResponse
from fastapi.security import HTTPBasic, HTTPBasicCredentials
from pydantic import BaseModel, ConfigDict, Field, HttpUrl
from sqlalchemy import Date, DateTime, ForeignKey, Integer, String, Text, create_engine, func, select
from sqlalchemy.orm import DeclarativeBase, Mapped, Session, mapped_column, relationship, sessionmaker

DATABASE_URL = os.getenv("DATABASE_URL", "sqlite:///./podcast.db")
engine = create_engine(DATABASE_URL, connect_args={"check_same_thread": False} if DATABASE_URL.startswith("sqlite") else {}, pool_pre_ping=True)
SessionLocal = sessionmaker(bind=engine)

class Base(DeclarativeBase):
    pass

class Episode(Base):
    __tablename__ = "episodes"
    id: Mapped[int] = mapped_column(primary_key=True)
    title: Mapped[str] = mapped_column(String(200))
    description: Mapped[str] = mapped_column(Text, default="")
    source_url: Mapped[str] = mapped_column(Text, default="")
    published_on: Mapped[date | None] = mapped_column(Date, nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc))
    clips: Mapped[list["Clip"]] = relationship(back_populates="episode", cascade="all, delete-orphan")

class Clip(Base):
    __tablename__ = "clips"
    id: Mapped[int] = mapped_column(primary_key=True)
    episode_id: Mapped[int] = mapped_column(ForeignKey("episodes.id"))
    hook: Mapped[str] = mapped_column(String(250))
    caption: Mapped[str] = mapped_column(Text, default="")
    platform: Mapped[str] = mapped_column(String(32), default="instagram")
    status: Mapped[str] = mapped_column(String(32), default="draft")
    scheduled_for: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
    asset_url: Mapped[str] = mapped_column(Text, default="")
    episode: Mapped[Episode] = relationship(back_populates="clips")

class Metric(Base):
    __tablename__ = "metrics"
    id: Mapped[int] = mapped_column(primary_key=True)
    recorded_on: Mapped[date] = mapped_column(Date)
    platform: Mapped[str] = mapped_column(String(32))
    plays: Mapped[int] = mapped_column(Integer, default=0)
    followers: Mapped[int] = mapped_column(Integer, default=0)
    engagement: Mapped[int] = mapped_column(Integer, default=0)

class EpisodeIn(BaseModel):
    title: str = Field(min_length=1, max_length=200)
    description: str = Field(default="", max_length=10000)
    source_url: str = Field(default="", max_length=2000)
    published_on: date | None = None

class EpisodeOut(EpisodeIn):
    id: int
    model_config = ConfigDict(from_attributes=True)

Platform = Literal["instagram", "facebook", "tiktok", "youtube", "linkedin"]
ClipStatus = Literal["draft", "review", "approved", "scheduled", "published"]

class ClipIn(BaseModel):
    episode_id: int
    hook: str = Field(min_length=1, max_length=250)
    caption: str = Field(default="", max_length=5000)
    platform: Platform = "instagram"
    asset_url: str = Field(default="", max_length=2000)

class ClipOut(ClipIn):
    id: int
    status: ClipStatus
    scheduled_for: datetime | None
    model_config = ConfigDict(from_attributes=True)

class StatusUpdate(BaseModel):
    status: ClipStatus
    scheduled_for: datetime | None = None

class MetricIn(BaseModel):
    recorded_on: date
    platform: Platform
    plays: int = Field(ge=0)
    followers: int = Field(ge=0)
    engagement: int = Field(ge=0)

class MetricOut(MetricIn):
    id: int
    model_config = ConfigDict(from_attributes=True)

security = HTTPBasic()
def require_auth(credentials: HTTPBasicCredentials = Depends(security)):
    username = os.getenv("APP_USER", "admin")
    password = os.getenv("APP_PASSWORD", "")
    if not password or not (secrets.compare_digest(credentials.username.encode(), username.encode()) and secrets.compare_digest(credentials.password.encode(), password.encode())):
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Invalid credentials", headers={"WWW-Authenticate": "Basic"})

def db_session():
    with SessionLocal() as session:
        yield session

@asynccontextmanager
async def lifespan(_app: FastAPI):
    Base.metadata.create_all(bind=engine)
    yield

app = FastAPI(title="Podcast Growth Studio", version="0.1.0", lifespan=lifespan)

@app.get("/", include_in_schema=False, dependencies=[Depends(require_auth)])
def index():
    return FileResponse(Path(__file__).parent / "static" / "index.html")

@app.get("/health")
def health():
    return {"status": "ok"}

@app.get("/api/dashboard", dependencies=[Depends(require_auth)])
def dashboard(db: Session = Depends(db_session)):
    return {
        "episodes": db.scalar(select(func.count()).select_from(Episode)) or 0,
        "clips": db.scalar(select(func.count()).select_from(Clip)) or 0,
        "awaiting_review": db.scalar(select(func.count()).select_from(Clip).where(Clip.status == "review")) or 0,
        "approved": db.scalar(select(func.count()).select_from(Clip).where(Clip.status == "approved")) or 0,
        "scheduled": db.scalar(select(func.count()).select_from(Clip).where(Clip.status == "scheduled")) or 0,
        "published": db.scalar(select(func.count()).select_from(Clip).where(Clip.status == "published")) or 0,
    }

@app.get("/api/episodes", response_model=list[EpisodeOut], dependencies=[Depends(require_auth)])
def list_episodes(db: Session = Depends(db_session)):
    return db.scalars(select(Episode).order_by(Episode.id.desc())).all()

@app.post("/api/episodes", response_model=EpisodeOut, status_code=201, dependencies=[Depends(require_auth)])
def create_episode(payload: EpisodeIn, db: Session = Depends(db_session)):
    episode = Episode(**payload.model_dump())
    db.add(episode)
    db.commit()
    db.refresh(episode)
    return episode

@app.get("/api/clips", response_model=list[ClipOut], dependencies=[Depends(require_auth)])
def list_clips(db: Session = Depends(db_session)):
    return db.scalars(select(Clip).order_by(Clip.id.desc())).all()

@app.post("/api/clips", response_model=ClipOut, status_code=201, dependencies=[Depends(require_auth)])
def create_clip(payload: ClipIn, db: Session = Depends(db_session)):
    if not db.get(Episode, payload.episode_id):
        raise HTTPException(404, "Episode not found")
    clip = Clip(**payload.model_dump())
    db.add(clip)
    db.commit()
    db.refresh(clip)
    return clip

@app.patch("/api/clips/{clip_id}", response_model=ClipOut, dependencies=[Depends(require_auth)])
def update_clip(clip_id: int, payload: StatusUpdate, db: Session = Depends(db_session)):
    clip = db.get(Clip, clip_id)
    if clip is None:
        raise HTTPException(404, "Clip not found")
    allowed = {
        "draft": {"review"}, "review": {"draft", "approved"},
        "approved": {"draft", "scheduled"}, "scheduled": {"approved", "published"},
        "published": set(),
    }
    if payload.status != clip.status and payload.status not in allowed[clip.status]:
        raise HTTPException(422, f"Invalid transition: {clip.status} → {payload.status}")
    if payload.status == "scheduled" and not (payload.scheduled_for or clip.scheduled_for):
        raise HTTPException(422, "scheduled_for is required to schedule a clip")
    if payload.status == "scheduled" and not clip.asset_url:
        raise HTTPException(422, "Add a clip asset URL before scheduling")
    clip.status = payload.status
    if payload.scheduled_for:
        clip.scheduled_for = payload.scheduled_for
    db.commit()
    db.refresh(clip)
    return clip

@app.get("/api/metrics", response_model=list[MetricOut], dependencies=[Depends(require_auth)])
def list_metrics(db: Session = Depends(db_session)):
    return db.scalars(select(Metric).order_by(Metric.recorded_on.desc(), Metric.id.desc()).limit(100)).all()

@app.post("/api/metrics", response_model=MetricOut, status_code=201, dependencies=[Depends(require_auth)])
def add_metric(payload: MetricIn, db: Session = Depends(db_session)):
    metric = Metric(**payload.model_dump())
    db.add(metric)
    db.commit()
    db.refresh(metric)
    return metric

class CaptionRequest(BaseModel):
    episode_id: int
    platform: Platform = "instagram"
    angle: str = Field(default="generational perspectives", max_length=200)

@app.post("/api/ideas", dependencies=[Depends(require_auth)])
async def generate_idea(payload: CaptionRequest, db: Session = Depends(db_session)):
    episode = db.get(Episode, payload.episode_id)
    if not episode:
        raise HTTPException(404, "Episode not found")
    fallback = {"hook": f"Mom and daughter have different takes on {episode.title}!", "caption": f"Two generations, one honest conversation. 🎙️ {episode.title} — what do you think? #MotherDaughterPodcast #PodcastClips", "source": "template"}
    base_url = os.getenv("LLM_BASE_URL", "").rstrip("/")
    if not base_url:
        return fallback
    prompt = f"Produce JSON only with keys hook and caption. Create a non-deceptive podcast promotional idea. Do not invent quotes, claims or facts. Episode title: {episode.title}. Description: {episode.description}. Channel: {payload.platform}. Angle: {payload.angle}. A human must review output."
    try:
        async with httpx.AsyncClient(timeout=20) as client:
            response = await client.post(f"{base_url}/chat/completions", headers={"Authorization": f"Bearer {os.getenv('LLM_API_KEY','not-needed')}"}, json={"model": os.getenv("LLM_MODEL", "local-model"), "messages": [{"role": "user", "content": prompt}], "response_format": {"type": "json_object"}})
            response.raise_for_status()
            import json
            result = json.loads(response.json()["choices"][0]["message"]["content"])
            if not isinstance(result.get("hook"), str) or not isinstance(result.get("caption"), str):
                raise ValueError("Invalid model response")
            return {"hook": result["hook"][:250], "caption": result["caption"][:5000], "source": "llm"}
    except (httpx.HTTPError, ValueError, KeyError, IndexError, TypeError):
        return {**fallback, "warning": "Local AI unavailable; returned template instead"}
