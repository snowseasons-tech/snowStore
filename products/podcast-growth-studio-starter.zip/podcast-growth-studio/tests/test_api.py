"""Run with APP_PASSWORD=test-secret DATABASE_URL=sqlite:///./test.db pytest -q."""
import os
os.environ.setdefault('APP_PASSWORD', 'test-secret')
os.environ.setdefault('DATABASE_URL', 'sqlite:///./test.db')
from fastapi.testclient import TestClient
from app.main import app

def test_workflow():
    with TestClient(app) as client:
        auth=('admin','test-secret')
        assert client.get('/api/episodes').status_code == 401
        r=client.post('/api/episodes',auth=auth,json={'title':'Mom vs Daughter: Episode 1'})
        assert r.status_code==201, r.text
        episode_id=r.json()['id']
        r=client.post('/api/clips',auth=auth,json={'episode_id':episode_id,'hook':'Who is right?'})
        assert r.status_code==201, r.text
        clip_id=r.json()['id']
        assert client.patch(f'/api/clips/{clip_id}',auth=auth,json={'status':'published'}).status_code==422
        assert client.patch(f'/api/clips/{clip_id}',auth=auth,json={'status':'review'}).status_code==200
        assert client.patch(f'/api/clips/{clip_id}',auth=auth,json={'status':'approved'}).status_code==200
        assert client.patch(f'/api/clips/{clip_id}',auth=auth,json={'status':'scheduled','scheduled_for':'2026-11-01T10:00:00Z'}).status_code==422
        assert client.get('/api/dashboard',auth=auth).json()['approved'] >= 1
