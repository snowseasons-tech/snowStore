# Podcast Growth Studio — Snow Seasons Tech

An **internal, single-client working MVP** for managing a mother–daughter podcast's promotional operations. Built with FastAPI, SQLAlchemy, PostgreSQL, Docker Compose, and a responsive vanilla-JS dashboard. Optional llama.cpp OpenAI-compatible endpoint for copy suggestions.

## Start

```bash
cp .env.example .env
# Set unique APP_PASSWORD and POSTGRES_PASSWORD, then ensure DATABASE_URL uses that same Postgres password.
docker compose up --build -d
docker compose ps
```

Visit **http://localhost:8000**. Use `APP_USER` and `APP_PASSWORD` from `.env` when your browser prompts for credentials. Interactive API docs: **http://localhost:8000/docs** (the docs page is accessible but all business API endpoints require credentials).

To run without Docker (SQLite local development only):

```bash
python -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
export APP_PASSWORD='change-this'
export DATABASE_URL='sqlite:///./podcast.db'
uvicorn app.main:app --reload
```

## What's functional

- Episodes: metadata, URL, optional publication date.
- Clips: draft copy, edited asset URL, target platform.
- Explicit clip workflow: draft → review → approved → scheduled → published. Scheduling is **a calendar record, not automatic publishing**. Published means manually confirmed after external posting.
- Dashboard counts and recorded metrics snapshots.
- Copy-suggestion endpoint: optional llama.cpp; labeled template fallback if not configured or if unavailable. Drafts require human verification.
- Basic Auth with constant-time credential comparison; localhost-only Compose port binding.
- `/health` endpoint and OpenAPI spec.

## Next production milestones

1. Add organizations, users, permission roles, and client-level row isolation; implement SSO or managed login, CSRF defense, secure sessions, audit logs, and rate limits. Do not expose prototype publicly.
2. Add Alembic migrations. `create_all` is for MVP only and will not migrate schemas.
3. Build secure object storage, upload validation, transcoding (FFmpeg), AI-assisted transcript extraction and timestamps, and actual clip rendering/preview.
4. Implement platform-specific OAuth and publishing using **approved official APIs**, token encryption and refresh, retry handling, and policy-compliant scheduling. Never store credentials in plaintext.
5. Collect actual platform analytics via authorized APIs; report audience growth and baseline-delta KPIs.
6. Add queue/workers (e.g. durable jobs) for slow tasks, observability, backups, tenancy tests, and CI.

## Test

```bash
APP_PASSWORD=test-secret DATABASE_URL=sqlite:///./test.db pytest -q
```

## Security / privacy

Only use publicly shareable clips and properly licensed audio/video. Obtain the podcast owner's authorization for hosting and social account operations. Avoid entering sensitive personal data into unapproved AI services. This is **not production-hardened**; use locally or behind an access-controlled private network until the controls above are added.
