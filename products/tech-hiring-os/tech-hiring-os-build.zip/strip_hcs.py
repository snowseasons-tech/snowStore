import re, sys, zipfile, shutil
src = sys.argv[1]; tmp = src + ".tmp"
with zipfile.ZipFile(src) as zi, zipfile.ZipFile(tmp, "w", zipfile.ZIP_DEFLATED) as zo:
    for it in zi.infolist():
        data = zi.read(it.filename)
        if it.filename.endswith(".xml"):
            data = re.sub(rb'<w:highlightCs [^>]*/>', b'', data)
        zo.writestr(it, data)
shutil.move(tmp, src)
print("stripped")
