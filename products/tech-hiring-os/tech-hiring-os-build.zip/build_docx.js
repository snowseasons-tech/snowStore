// Build Offer_Templates.docx
const fs = require("fs");
const {
  Document, Packer, Paragraph, TextRun, HeadingLevel, AlignmentType, Table, TableRow, TableCell,
  WidthType, ShadingType, BorderStyle, LevelFormat, PageBreak, Header, Footer, PageNumber, TabStopType,
} = require("docx");

const OUT = process.argv[2];
const NAVY = "1F2A44", TEAL = "0F766E", MUTED = "6B7280";
const CONTENT_W = 9360; // 6.5in at 1in margins

// Inline markup: {{TOKEN}} -> yellow highlight; [[text]] -> optional clause (teal italic); **bold**
function runs(text, base = {}) {
  const out = [];
  const re = /(\{\{[A-Z_]+\}\}|\[\[(?:(?!\]\]).)+\]\]|\*\*[^*]+\*\*)/g;
  let last = 0, m;
  while ((m = re.exec(text))) {
    if (m.index > last) out.push(new TextRun({ text: text.slice(last, m.index), ...base }));
    const t = m[0];
    if (t.startsWith("{{")) out.push(new TextRun({ text: t, highlight: "yellow", ...base }));
    else if (t.startsWith("[[")) {
      const ob = { ...base, italics: true, color: TEAL };
      out.push(new TextRun({ text: "[", ...ob }), ...runs(t.slice(2, -2), ob), new TextRun({ text: "]", ...ob }));
    }
    else out.push(new TextRun({ text: t.slice(2, -2), bold: true, ...base }));
    last = m.index + t.length;
  }
  if (last < text.length) out.push(new TextRun({ text: text.slice(last), ...base }));
  return out;
}
const p = (text, opts = {}) => new Paragraph({ children: runs(text, opts.run || {}), spacing: { after: 140, line: 276 }, ...opts.para });
const h1 = (text) => new Paragraph({ heading: HeadingLevel.HEADING_1, children: [new TextRun(text)] });
const h2 = (text) => new Paragraph({ heading: HeadingLevel.HEADING_2, children: [new TextRun(text)] });
const h3 = (text) => new Paragraph({ heading: HeadingLevel.HEADING_3, children: [new TextRun(text)] });
const bullet = (text) => new Paragraph({ numbering: { reference: "bullets", level: 0 }, children: runs(text), spacing: { after: 80 } });
const check = (text) => new Paragraph({ numbering: { reference: "checks", level: 0 }, children: runs(text), spacing: { after: 80 } });
const numbered = (ref, text) => new Paragraph({ numbering: { reference: ref, level: 0 }, children: runs(text), spacing: { after: 80 } });
const brk = () => new Paragraph({ children: [new PageBreak()] });
const note = (text) => new Paragraph({
  children: runs(text, { size: 18, color: "374151" }),
  shading: { type: ShadingType.CLEAR, fill: "EEF2F7", color: "auto" },
  border: { left: { style: BorderStyle.SINGLE, size: 18, color: TEAL, space: 8 } },
  spacing: { before: 60, after: 200 }, indent: { left: 160, right: 160 },
});
const clause = (head, body) => new Paragraph({
  children: [new TextRun({ text: head + ". ", bold: true }), ...runs(body)],
  spacing: { after: 140, line: 276 },
});
const rule = () => new Paragraph({ border: { bottom: { style: BorderStyle.SINGLE, size: 6, color: "D1D5DB", space: 1 } }, spacing: { after: 200 } });

const border = { style: BorderStyle.SINGLE, size: 4, color: "D1D5DB" };
const borders = { top: border, bottom: border, left: border, right: border };
function table(rows, widths, { header = true } = {}) {
  return new Table({
    width: { size: CONTENT_W, type: WidthType.DXA },
    columnWidths: widths,
    rows: rows.map((r, i) => new TableRow({
      tableHeader: header && i === 0,
      children: r.map((c, j) => new TableCell({
        borders, width: { size: widths[j], type: WidthType.DXA },
        shading: header && i === 0 ? { type: ShadingType.CLEAR, fill: NAVY, color: "auto" }
          : (i % 2 === 0 ? { type: ShadingType.CLEAR, fill: "F9FAFB", color: "auto" } : undefined),
        margins: { top: 70, bottom: 70, left: 110, right: 110 },
        children: [new Paragraph({ children: runs(String(c), header && i === 0 ? { bold: true, color: "FFFFFF", size: 18 } : { size: 18 }) })],
      })),
    })),
  });
}
const sp = (after = 120) => new Paragraph({ spacing: { after }, children: [] });

// ---------- shared letter blocks
function letterTop(title) {
  return [
    new Paragraph({ children: [new TextRun({ text: "{{COMPANY_NAME}}", bold: true, size: 28, color: NAVY, highlight: "yellow" })], spacing: { after: 40 } }),
    new Paragraph({ children: [new TextRun({ text: "[Company address  |  website]", italics: true, color: TEAL, size: 18 })], spacing: { after: 300 } }),
    p("{{OFFER_DATE}}"),
    p("**PERSONAL AND CONFIDENTIAL**"),
    p("{{CANDIDATE_NAME}}", { para: { spacing: { after: 240 } } }),
    p(`**Re: ${title} - {{JOB_TITLE}}**`),
    p("Dear {{CANDIDATE_FIRST_NAME}},"),
  ];
}
function signatures(extraLine) {
  const rows = [
    p("Sincerely,", { para: { spacing: { before: 200, after: 500 } } }),
    p("______________________________"),
    p("{{SIGNATORY_NAME}}", { para: { spacing: { after: 20 } } }),
    p("{{SIGNATORY_TITLE}}, {{COMPANY_NAME}}", { para: { spacing: { after: 400 } } }),
    rule(),
    p("**Acceptance**"),
    p(extraLine || "I accept this offer of employment on the terms set out in this letter, and confirm that I am not relying on any promises or representations that are not contained in it."),
    p("Signature: ______________________________        Date: ________________", { para: { spacing: { before: 300 } } }),
    p("Printed name: {{CANDIDATE_NAME}}        Confirmed start date: {{START_DATE}}"),
  ];
  return rows;
}
const intro = "On behalf of {{COMPANY_NAME}}, I am delighted to offer you the position of {{JOB_TITLE}} ({{LEVEL}}) on our {{DEPARTMENT}} team. Everyone who met you was impressed, and we believe you will make a real difference here. This letter sets out the main terms of our offer.";

// ---------- Template A: standard US
const templateA = [
  h1("Template A - Standard Full-Time Offer (US, at-will)"),
  note("Use for salaried, full-time employees in the United States. Replace every yellow {{TOKEN}} with the value from the Offer Generator sheet, delete optional [bracketed] clauses you do not need, and remove this note before sending."),
  ...letterTop("Offer of Employment"),
  p(intro),
  clause("Position and start date", "You will report to {{MANAGER_NAME}}, {{MANAGER_TITLE}}. This is a {{EMPLOYMENT_TYPE}} position based in {{WORK_LOCATION}}. Your anticipated start date is {{START_DATE}}. [[Optional: This role is eligible for remote work under our remote work policy.]]"),
  clause("Base salary", "Your starting base salary will be {{BASE_SALARY}} per year, paid {{PAY_FREQUENCY}} in accordance with the company's standard payroll practices and subject to applicable withholdings and deductions. Your salary will be reviewed as part of our regular compensation cycle."),
  clause("Annual bonus", "You will be eligible for an annual target bonus of {{BONUS_TARGET_PCT}} of your base salary ({{BONUS_TARGET_AMOUNT}}), based on company and individual performance and subject to the terms of the applicable bonus plan. You must be employed on the payment date to earn a bonus. [[Delete this paragraph if the role is not bonus-eligible.]]"),
  clause("Sign-on bonus", "You will receive a one-time sign-on bonus of {{SIGN_ON_BONUS}}, less applicable withholdings, paid with your first regular paycheck. If you resign or are terminated for cause within 12 months of your start date, you agree to repay a pro-rated portion of the gross amount. [[Delete if not applicable.]]"),
  clause("Equity", "Subject to approval by the company's Board of Directors, you will be granted {{EQUITY_UNITS}} {{EQUITY_TYPE}}. The grant will vest over {{VESTING_SCHEDULE}}, subject to your continued service, and will be governed by the company's equity incentive plan and your grant agreement. [[For options: The exercise price will equal the fair market value of the company's common stock on the grant date, as determined by the Board.]]"),
  clause("Benefits and time off", "You will be eligible to participate in the employee benefit plans the company makes available to similarly situated employees, including [[medical, dental and vision insurance, a 401(k) plan, and paid time off of X days per year]], subject to the terms of those plans. The company may change its benefits from time to time."),
  clause("Conditions of this offer", "This offer is contingent on (a) satisfactory completion of a background check, conducted in compliance with applicable law; (b) your providing documents that establish your identity and eligibility to work in the United States within three business days of your start date; and (c) your signing the company's Confidential Information and Invention Assignment Agreement. You confirm that you are not bound by any agreement that would prevent you from performing this role, and you agree not to bring or use any confidential information belonging to a former employer."),
  clause("At-will employment", "Your employment with {{COMPANY_NAME}} is at-will. This means that either you or the company may end the employment relationship at any time, with or without cause or advance notice. The at-will nature of your employment can only be changed in a written agreement signed by you and the company's Chief Executive Officer."),
  clause("Entire offer", "This letter, together with the agreements referenced in it, is the complete offer of employment and replaces any prior discussions or representations, written or oral."),
  p("This offer will remain open until {{OFFER_EXPIRY_DATE}}. To accept, please sign below and return a copy to me. We are excited about what we can build together and look forward to welcoming you to the team."),
  ...signatures(),
];

// ---------- Template B: sales
const templateB = [
  h1("Template B - Sales Offer (Base + Variable / OTE)"),
  note("Use for quota-carrying and variable-pay roles (SDR, AE, Sales Engineer, CSM, Sales Manager). Always send the written sales compensation plan with or before this letter, and make sure the two documents agree."),
  ...letterTop("Offer of Employment"),
  p(intro),
  clause("Position and start date", "You will report to {{MANAGER_NAME}}, {{MANAGER_TITLE}}, and will be based in {{WORK_LOCATION}}. This is a {{EMPLOYMENT_TYPE}} position with an anticipated start date of {{START_DATE}}."),
  clause("Base salary", "Your starting base salary will be {{BASE_SALARY}} per year, paid {{PAY_FREQUENCY}}, subject to applicable withholdings."),
  clause("Variable compensation", "You will be eligible to earn variable compensation with an annual on-target value of {{VARIABLE_TARGET}}, for total on-target earnings (OTE) of {{OTE}} at 100% attainment of your quota. Your quota, territory or book of business, commission rates, accelerators and payment timing will be set out in the {{COMPANY_NAME}} Sales Compensation Plan, which governs how commissions are earned and paid. The company may update the plan, quotas and territories from time to time, with notice to you."),
  clause("Ramp period", "[[Optional: During your first X months, you will receive a non-recoverable draw of {{CURRENCY}} [amount] per month in place of commissions, after which you will be paid under the plan with a ramped quota of [X]% in month X.]]"),
  clause("Sign-on bonus", "[[Optional: You will receive a one-time sign-on bonus of {{SIGN_ON_BONUS}}, subject to the repayment terms described in our standard offer letter.]]"),
  clause("Equity", "Subject to Board approval, you will be granted {{EQUITY_UNITS}} {{EQUITY_TYPE}}, vesting over {{VESTING_SCHEDULE}}, under the company's equity incentive plan and your grant agreement."),
  clause("Benefits", "You will be eligible for the benefit programs the company makes available to similarly situated employees, subject to the terms of those plans."),
  clause("Conditions and employment terms", "This offer is contingent on a satisfactory background check, verification of your eligibility to work, and your signing the company's confidentiality and invention assignment agreement. [[US: Your employment is at-will, as described in our standard offer letter.]] [[Outside the US: Your employment will be governed by a local employment agreement.]]"),
  p("This offer will remain open until {{OFFER_EXPIRY_DATE}}. We cannot wait to see you build pipeline with us."),
  ...signatures("I accept this offer of employment on the terms set out in this letter and acknowledge receipt of the Sales Compensation Plan."),
];

// ---------- Template C: senior/leadership
const templateC = [
  h1("Template C - Senior & Leadership Offer"),
  note("Use for L4-L5 and manager hires (Staff/Principal, Directors, VPs). Leadership offers often include negotiated terms such as acceleration, severance or relocation. Have counsel review every leadership offer, and get any non-standard term approved on the Offer Approval Form first."),
  ...letterTop("Offer of Employment"),
  p("On behalf of {{COMPANY_NAME}} and its Board of Directors, I am delighted to offer you the position of {{JOB_TITLE}}. You will play a central role in [[describe the mandate in one sentence, e.g. scaling our engineering organisation through our next stage of growth]]."),
  clause("Role and reporting", "You will report to {{MANAGER_NAME}}, {{MANAGER_TITLE}}, and be based in {{WORK_LOCATION}}, starting on {{START_DATE}}. [[Optional: You will be a member of the company's leadership team.]]"),
  clause("Base salary", "Your starting base salary will be {{BASE_SALARY}} per year, paid {{PAY_FREQUENCY}}, subject to applicable withholdings, and reviewed annually."),
  clause("Annual bonus", "You will be eligible for an annual target bonus of {{BONUS_TARGET_PCT}} of base salary ({{BONUS_TARGET_AMOUNT}}), based on goals agreed with {{MANAGER_NAME}} and company performance. [[Optional: Your first-year bonus will not be pro-rated.]]"),
  clause("Equity", "Subject to Board approval, you will be granted {{EQUITY_UNITS}} {{EQUITY_TYPE}}, vesting over {{VESTING_SCHEDULE}}. Based on the company's current fully diluted capitalisation, this grant represents approximately [[X.XX]]% of the company. [[Optional: The grant will allow early exercise.]] [[Optional double-trigger acceleration: If your employment is terminated without cause or you resign for good reason within 12 months after a change in control, [100]% of your then-unvested shares will vest.]]"),
  clause("Sign-on and relocation", "[[Optional: You will receive a sign-on bonus of {{SIGN_ON_BONUS}}, and the company will reimburse reasonable relocation expenses up to {{CURRENCY}} [amount] in line with its relocation policy, both subject to pro-rated repayment if you resign within 12 months.]]"),
  clause("Severance", "[[Optional: If the company terminates your employment without cause, subject to your signing and not revoking a release of claims, you will receive continued base salary for [X] months and company-paid health coverage for the same period.]]"),
  clause("Benefits", "You will be eligible for the benefits available to the company's senior employees, subject to plan terms."),
  clause("Conditions", "This offer is contingent on a satisfactory background and reference check, verification of your eligibility to work, and your signing the company's confidentiality and invention assignment agreement. You confirm that accepting this role does not breach any obligation you owe to a current or former employer."),
  clause("Employment relationship", "[[US: Your employment is at-will, as described in our standard offer letter.]] [[Outside the US: Your employment will be governed by a local executive employment agreement, including notice and restrictive covenant terms that comply with local law.]]"),
  p("This offer will remain open until {{OFFER_EXPIRY_DATE}}. I am genuinely excited about what we will build together."),
  ...signatures(),
];

// ---------- Template D: international
const templateD = [
  h1("Template D - International Offer (Local Entity or Employer of Record)"),
  note("Use for hires outside the United States. Most countries require a formal written employment contract with mandatory terms (probation, notice, working time, leave, governing law). Treat this letter as the offer summary and attach the local contract prepared by local counsel or your Employer of Record (EOR). At-will language does not apply."),
  ...letterTop("Offer of Employment"),
  p(intro),
  clause("Employer", "You will be employed by [[local entity name, or Employer of Record name]] (the \"Employer\") and will provide services to {{COMPANY_NAME}}. Your detailed terms will be set out in the enclosed employment contract, which will take precedence over this letter if there is any difference between them."),
  clause("Position and start date", "You will work as {{JOB_TITLE}} ({{LEVEL}}), reporting to {{MANAGER_NAME}}, {{MANAGER_TITLE}}, based in {{WORK_LOCATION}}, starting on {{START_DATE}}."),
  clause("Salary", "Your gross annual base salary will be {{BASE_SALARY}}, paid in [[12 / 13 / 14]] instalments in line with local payroll practice, subject to statutory deductions. [[Optional: This includes / is in addition to any statutory 13th-month or holiday allowance.]]"),
  clause("Bonus or variable pay", "You will be eligible for {{BONUS_TARGET_PCT}} target annual bonus ({{BONUS_TARGET_AMOUNT}}) [[or, for sales roles: variable compensation of {{VARIABLE_TARGET}} at target, OTE {{OTE}}]] under the applicable plan."),
  clause("Equity", "Subject to Board approval, you will be offered {{EQUITY_UNITS}} {{EQUITY_TYPE}} in {{COMPANY_NAME}}, vesting over {{VESTING_SCHEDULE}}, under the equity plan and any local sub-plan. Tax treatment of equity differs by country; we recommend you take independent tax advice."),
  clause("Probation and notice", "Your employment will begin with a probationary period of [[X]] months. After probation, the notice period will be [[X]] weeks or months, or longer where required by law or an applicable collective agreement."),
  clause("Working time and leave", "Your normal working hours will be [[X]] hours per week. You will be entitled to [[X]] days of paid annual leave per year plus public holidays, and to statutory sick pay, parental leave and other leave required by local law."),
  clause("Benefits", "You will be eligible for the benefits provided by the Employer in your country, which may include [[pension contributions, private health insurance, meal or transport allowances]]."),
  clause("Conditions", "This offer is contingent on verification of your right to work in [[country]], any background checks permitted by local law, and signing the employment contract and the company's confidentiality and intellectual property agreement."),
  clause("Governing law", "Your employment will be governed by the laws of [[country / state]]."),
  p("This offer will remain open until {{OFFER_EXPIRY_DATE}}. We are thrilled at the prospect of you joining us."),
  ...signatures("I accept this offer and understand that my detailed terms of employment are set out in the enclosed employment contract."),
];

// ---------- Exhibit: offer summary
const exhibit = [
  h1("Exhibit 1 - Offer at a Glance"),
  note("Attach to any template as a one-page summary, or send alongside the verbal offer. Candidates compare offers on total compensation, so make the full picture easy to see."),
  p("**{{COMPANY_NAME}} - Compensation summary for {{CANDIDATE_NAME}}**"),
  table([
    ["Item", "Detail"],
    ["Role", "{{JOB_TITLE}} ({{LEVEL}}), {{DEPARTMENT}}"],
    ["Location / type", "{{WORK_LOCATION}} - {{EMPLOYMENT_TYPE}}"],
    ["Start date", "{{START_DATE}}"],
    ["Reports to", "{{MANAGER_NAME}}, {{MANAGER_TITLE}}"],
    ["Base salary", "{{BASE_SALARY}} per year, paid {{PAY_FREQUENCY}}"],
    ["Bonus at target", "{{BONUS_TARGET_PCT}} ({{BONUS_TARGET_AMOUNT}})"],
    ["Variable at target / OTE (sales)", "{{VARIABLE_TARGET}} / {{OTE}}"],
    ["Sign-on bonus", "{{SIGN_ON_BONUS}}"],
    ["Equity", "{{EQUITY_UNITS}} {{EQUITY_TYPE}}, vesting over {{VESTING_SCHEDULE}}"],
    ["Benefits", "[[Health, retirement, time off, learning budget, equipment]]"],
    ["Offer expires", "{{OFFER_EXPIRY_DATE}}"],
  ], [3000, 6360]),
  sp(200),
  h3("Understanding your equity"),
  bullet("**Stock options** give you the right to buy shares at a fixed exercise price. Their value is the difference between the share value and that price when you exercise or sell."),
  bullet("**Restricted stock units (RSUs)** are shares delivered to you as they vest. Their value is the share price on the vesting date."),
  bullet("**Vesting** means you earn the grant over time. With a one-year cliff, nothing vests for the first 12 months, then 25% vests and the rest vests monthly."),
  bullet("Private-company equity is illiquid and its value can go up, down or to zero. Any value we show you is an illustration, not a promise. Take independent tax advice."),
];

// ---------- Approval form
const approval = [
  h1("Offer Approval Form"),
  note("Required when the Offer Generator shows \"Exception: VP + Finance sign-off\": the base is above the band maximum, the sign-on bonus exceeds the Settings threshold, or equity exceeds the guideline. Attach the Band Calculator output."),
  table([
    ["Field", "Entry"],
    ["Candidate", "{{CANDIDATE_NAME}}"],
    ["Role / level / location", "{{JOB_TITLE}} / {{LEVEL}} / {{WORK_LOCATION}}"],
    ["Req ID (Hiring Plan)", ""],
    ["Proposed base", "{{BASE_SALARY}}"],
    ["Band min / mid / max", ""],
    ["Compa-ratio and band status", ""],
    ["Sign-on bonus", "{{SIGN_ON_BONUS}}"],
    ["Equity (units / guideline units)", "{{EQUITY_UNITS}} / "],
    ["Interview scorecard result", "Weighted score: ____   Recommendation: ____________"],
    ["Competing offers (if known)", ""],
    ["Reason for exception", ""],
    ["Internal equity check: peers in same role/level", ""],
  ], [3400, 5960]),
  sp(200),
  table([
    ["Approver", "Name", "Decision", "Date"],
    ["Hiring manager", "", "Approve / Reject", ""],
    ["Recruiting lead", "", "Approve / Reject", ""],
    ["Department VP", "", "Approve / Reject", ""],
    ["Finance", "", "Approve / Reject", ""],
    ["CEO (leadership hires only)", "", "Approve / Reject", ""],
  ], [2800, 2600, 2200, 1760]),
];

// ---------- Verbal offer script
const script = [
  h1("Verbal Offer Call Script"),
  note("The hiring manager makes the call; the recruiter joins or follows up the same day with the written offer. Aim for 20 minutes. Lead with excitement, not numbers."),
  h3("1. Open with the decision (2 minutes)"),
  p("\"Hi {{CANDIDATE_FIRST_NAME}}, thanks for making time. I'll get straight to it: the team loved meeting you, and I'm delighted to offer you the role of {{JOB_TITLE}}.\""),
  h3("2. Explain why them (3 minutes)"),
  p("Share two or three specific strengths from the scorecard evidence, and the impact you expect them to have in the first year (use the Outcomes from the scorecard)."),
  h3("3. Walk through the offer (5 minutes)"),
  bullet("Base salary {{BASE_SALARY}}, and how it sits in our band for the level."),
  bullet("Bonus {{BONUS_TARGET_PCT}} or variable {{VARIABLE_TARGET}} (OTE {{OTE}}), with how it is earned."),
  bullet("Equity {{EQUITY_UNITS}} {{EQUITY_TYPE}}, vesting over {{VESTING_SCHEDULE}}. Explain it plainly; offer an equity walkthrough call."),
  bullet("Sign-on {{SIGN_ON_BONUS}} (if any), benefits highlights, start date {{START_DATE}}."),
  h3("4. Listen (5 minutes)"),
  p("\"How does that land with you?\" Then stop talking. Ask: \"What else are you weighing? What would make this an easy yes?\" Note every concern; do not negotiate on the spot unless you have pre-approved room."),
  h3("5. Close the call (3 minutes)"),
  p("\"You'll have the written offer by end of day. It's open until {{OFFER_EXPIRY_DATE}}. Can we schedule 15 minutes on [day] to answer any questions? Who else would be useful for you to talk to: a future peer, our CEO?\""),
  h3("Do and don't"),
  table([
    ["Do", "Don't"],
    ["Make the call within 24 hours of the debrief", "Leave the offer to email alone"],
    ["Share the band and where the offer sits", "Ask for current or past salary where that is prohibited"],
    ["Offer to connect them with future peers", "Create artificial pressure (\"exploding\" offers)"],
    ["Log the call outcome in the Offer Tracker", "Promise anything not in the written offer"],
  ], [4680, 4680]),
];

// ---------- Emails
const email = (subject, lines) => [
  p(`**Subject:** ${subject}`, { para: { spacing: { after: 80 } } }),
  ...lines.map((l) => p(l)),
  rule(),
];
const emails = [
  h1("Email Templates"),
  h2("1. Written offer cover email"),
  ...email("Your offer from {{COMPANY_NAME}} - {{JOB_TITLE}}", [
    "Hi {{CANDIDATE_FIRST_NAME}},",
    "It was great speaking with you today. As promised, your offer letter for the {{JOB_TITLE}} role is attached, along with a one-page summary of the full compensation package.",
    "The offer is open until {{OFFER_EXPIRY_DATE}}. If you have any questions about the role, equity or benefits, reply here or grab time with me at [scheduling link]. Happy to set up a call with a future teammate too.",
    "We're really excited about the possibility of you joining us.",
    "Best,  {{MANAGER_NAME}}",
  ]),
  h2("2. Check-in while the offer is open"),
  ...email("Any questions on your offer?", [
    "Hi {{CANDIDATE_FIRST_NAME}},",
    "Just checking in to see whether any questions have come up as you think through the offer. Several people on the team have asked whether you'll be joining, which I'm taking as a good sign.",
    "Would 15 minutes on [day] be helpful? I'm also happy to connect you with [name, role] if you'd like an unfiltered view of what it's like to work here.",
    "Best,  {{MANAGER_NAME}}",
  ]),
  h2("3. Response to a counter-offer or negotiation request"),
  ...email("Re: Your offer", [
    "Hi {{CANDIDATE_FIRST_NAME}},",
    "Thank you for being open with me about [the competing offer / your expectations]. I've reviewed it with the team.",
    "[[If you can move:]] We've updated your offer to [change], which places you at [position] in our band for the level. The revised letter is attached and is open until [date].",
    "[[If you can't move on base:]] Our bands are set to keep pay fair for everyone at the same level, so we aren't able to move the base salary. What we can do is [sign-on / equity / start date / scope], and I'd love to talk through how growth and compensation reviews work here.",
    "Best,  {{MANAGER_NAME}}",
  ]),
  h2("4. Offer extension"),
  ...email("Your offer - extended to [new date]", [
    "Hi {{CANDIDATE_FIRST_NAME}},",
    "I know this is a big decision. We're happy to extend your offer until [new date]. If there's anything we can do to help you decide, just let me know.",
    "Best,  {{MANAGER_NAME}}",
  ]),
  h2("5. Acknowledging a declined offer"),
  ...email("Thank you, {{CANDIDATE_FIRST_NAME}}", [
    "Hi {{CANDIDATE_FIRST_NAME}},",
    "Thank you for letting me know, and for the care you put into the decision. We're disappointed, but we respect it, and I wish you every success in your new role.",
    "If you're open to it, I'd value one sentence on what tipped the decision, so we can keep improving. And if things change in future, our door is open.",
    "Best,  {{MANAGER_NAME}}",
  ]),
  h2("6. Welcome email after acceptance"),
  ...email("Welcome to {{COMPANY_NAME}}!", [
    "Hi {{CANDIDATE_FIRST_NAME}},",
    "We're thrilled you've accepted! Your start date is {{START_DATE}}. Here's what happens next:",
    "- In the next few days, you'll receive paperwork and equipment details from our People team.",
    "- Your onboarding buddy is [name]. They'll reach out before your first day.",
    "- Your first week's agenda and your 30-60-90 day plan will arrive the week before you start.",
    "If you have any questions before then, just reply to this email. Welcome aboard!",
    "Best,  {{MANAGER_NAME}}",
  ]),
];

// ---------- Checklist + glossary
const tokens = [
  ["{{COMPANY_NAME}}", "Settings > Company name", "Northwind Labs"],
  ["{{CANDIDATE_NAME}} / {{CANDIDATE_FIRST_NAME}}", "Offer Generator > Candidate full name", "Jordan Rivera / Jordan"],
  ["{{JOB_TITLE}}", "Salary Benchmarks job title for role + level", "Senior Software Engineer"],
  ["{{LEVEL}}", "Offer Generator > Level", "L3"],
  ["{{DEPARTMENT}}", "Role family", "Engineering"],
  ["{{WORK_LOCATION}}", "Offer Generator > Work location", "US Tier 2 - Boston / LA / Austin / DC"],
  ["{{EMPLOYMENT_TYPE}}", "Offer Generator > Employment type", "full-time, exempt"],
  ["{{START_DATE}}", "Offer Generator > Start date", "December 7, 2026"],
  ["{{MANAGER_NAME}} / {{MANAGER_TITLE}}", "Offer Generator", "Alex Morgan / Director of Engineering"],
  ["{{CURRENCY}}", "Settings > location currency", "USD"],
  ["{{BASE_SALARY}}", "Offer Generator > Base salary", "USD 186,000"],
  ["{{PAY_FREQUENCY}}", "Settings > Default pay frequency", "semi-monthly"],
  ["{{BONUS_TARGET_PCT}} / {{BONUS_TARGET_AMOUNT}}", "Salary Benchmarks bonus % x base", "5% / USD 9,300"],
  ["{{OTE}} / {{VARIABLE_TARGET}}", "Base / base share of OTE (sales roles)", "USD 280,000 / USD 140,000 (AE example)"],
  ["{{SIGN_ON_BONUS}}", "Offer Generator > Sign-on bonus", "USD 10,000"],
  ["{{EQUITY_UNITS}} / {{EQUITY_TYPE}}", "Offer Generator", "64,000 / stock options"],
  ["{{VESTING_SCHEDULE}}", "Settings > Default vesting", "4 years with a 1-year cliff, then monthly"],
  ["{{OFFER_DATE}} / {{OFFER_EXPIRY_DATE}}", "Offer date + Settings > Offer expiry days", "October 22, 2026 / October 27, 2026"],
  ["{{SIGNATORY_NAME}} / {{SIGNATORY_TITLE}}", "Offer Generator", "Sam Lee / Chief Executive Officer"],
];
const review = [
  h1("Legal & Compliance Review Checklist"),
  note("Run through this list for every new template you adopt and for each new country or US state you hire in. It is a prompt for your counsel, not a substitute for legal advice."),
  check("At-will language is used only for US employees, and nothing elsewhere in the letter contradicts it."),
  check("Pay-transparency rules are met: salary range disclosed in the job post or offer where required (for example several US states and cities, and the EU Pay Transparency Directive, which member states must apply from June 2026)."),
  check("No salary-history questions in jurisdictions that ban them."),
  check("Exempt / non-exempt (or local equivalent) classification is correct for the role and salary level."),
  check("Background checks follow FCRA or local rules, including fair-chance and ban-the-box timing."),
  check("Non-compete and non-solicit terms are enforceable where the employee lives (for example, California generally prohibits non-competes)."),
  check("Equity language matches the equity plan; options are granted at fair market value (409A in the US)."),
  check("Commission terms match the written sales compensation plan, and plans are provided where state law requires (for example, California)."),
  check("Sign-on repayment clauses comply with local wage-deduction and repayment rules."),
  check("International offers have a compliant local contract (probation, notice, leave, working time, governing law)."),
  check("Candidate personal data in the workbook and documents is stored and retained in line with your privacy policy and local data protection law."),
  sp(200),
  h1("Placeholder Glossary"),
  p("Every token below is produced by the Offer Generator sheet in Hiring_OS_2026.xlsx (section 3, Merge fields). Optional clauses appear as [teal bracketed italic text]: complete or delete them before sending."),
  table([["Token", "Source in workbook", "Example"], ...tokens], [3300, 3360, 2700]),
];

// ---------- How to use + title
const howTo = [
  new Paragraph({ children: [new TextRun({ text: "TECH HIRING & COMPENSATION BENCHMARK OS", size: 18, color: TEAL, bold: true })], spacing: { before: 1800, after: 120 } }),
  new Paragraph({ children: [new TextRun({ text: "Offer Letter Kit 2026", size: 56, bold: true, color: NAVY })], spacing: { after: 120 } }),
  new Paragraph({ children: [new TextRun({ text: "Offer letter templates, approval form, call script and candidate emails, ready to merge from Hiring_OS_2026.xlsx.", size: 24, color: "374151" })], spacing: { after: 600 } }),
  table([
    ["Contents", "Use when"],
    ["Template A - Standard full-time offer (US)", "Salaried US employees"],
    ["Template B - Sales offer (base + variable)", "Quota-carrying and OTE roles"],
    ["Template C - Senior & leadership offer", "L4-L5, Directors and above"],
    ["Template D - International offer", "Hires outside the US (local entity or EOR)"],
    ["Exhibit 1 - Offer at a glance", "One-page summary to attach to any offer"],
    ["Offer Approval Form", "Above band, large sign-on or equity above guideline"],
    ["Verbal Offer Call Script", "Hiring manager's offer call"],
    ["Email Templates (6)", "Cover, check-in, counter, extension, decline, welcome"],
    ["Legal checklist & placeholder glossary", "Before first use, and for each new jurisdiction"],
  ], [5200, 4160]),
  sp(300),
  p("This kit is a drafting aid, not legal advice. Employment law differs by country, state and city. Have qualified employment counsel review each template before use.", { run: { size: 18, color: MUTED, italics: true } }),
  brk(),
  h1("How to Use This Kit"),
  numbered("steps", "Complete the offer inputs on the **Offer Generator** sheet of Hiring_OS_2026.xlsx and confirm the approval route."),
  numbered("steps", "If the route says **Exception**, complete the Offer Approval Form in this kit and collect sign-offs before the verbal offer."),
  numbered("steps", "Make the verbal offer using the call script."),
  numbered("steps", "Copy the template you need into a new document. Replace each yellow {{TOKEN}} with the value in the **Merge fields** table: use Find & Replace (Ctrl/Cmd + H) token by token, or use Word Mail Merge with the workbook as the data source."),
  numbered("steps", "Complete or delete every [teal optional clause], remove the grey guidance notes, and clear yellow highlighting (Home > Text Highlight Color > No Color)."),
  numbered("steps", "Send the letter with the cover email, then log it in the **Offer Tracker** sheet."),
  sp(),
  h3("Formatting key"),
  table([
    ["Looks like", "Means"],
    ["{{BASE_SALARY}}", "Merge field: replace with the workbook value"],
    ["[[Optional clause text]]", "Optional or variable wording: complete, adapt or delete"],
    ["Shaded box with a teal bar", "Guidance for the hiring team: delete before sending"],
  ], [3600, 5760]),
];

const doc = new Document({
  creator: "Tech Hiring OS",
  title: "Offer Letter Kit 2026",
  description: "Offer letter templates for the Tech Hiring & Compensation Benchmark OS",
  styles: {
    default: { document: { run: { font: "Arial", size: 21 } } },
    paragraphStyles: [
      { id: "Heading1", name: "Heading 1", basedOn: "Normal", next: "Normal", quickFormat: true,
        run: { size: 32, bold: true, font: "Arial", color: NAVY }, paragraph: { spacing: { before: 120, after: 200 }, outlineLevel: 0 } },
      { id: "Heading2", name: "Heading 2", basedOn: "Normal", next: "Normal", quickFormat: true,
        run: { size: 25, bold: true, font: "Arial", color: TEAL }, paragraph: { spacing: { before: 240, after: 120 }, outlineLevel: 1 } },
      { id: "Heading3", name: "Heading 3", basedOn: "Normal", next: "Normal", quickFormat: true,
        run: { size: 22, bold: true, font: "Arial", color: NAVY }, paragraph: { spacing: { before: 200, after: 80 }, outlineLevel: 2 } },
    ],
  },
  numbering: {
    config: [
      { reference: "bullets", levels: [{ level: 0, format: LevelFormat.BULLET, text: "•", alignment: AlignmentType.LEFT, style: { paragraph: { indent: { left: 540, hanging: 300 } } } }] },
      { reference: "checks", levels: [{ level: 0, format: LevelFormat.BULLET, text: "☐", alignment: AlignmentType.LEFT, style: { paragraph: { indent: { left: 540, hanging: 340 } } } }] },
      { reference: "steps", levels: [{ level: 0, format: LevelFormat.DECIMAL, text: "%1.", alignment: AlignmentType.LEFT, style: { paragraph: { indent: { left: 540, hanging: 340 } } } }] },
    ],
  },
  sections: [{
    properties: { page: { size: { width: 12240, height: 15840 }, margin: { top: 1440, right: 1440, bottom: 1440, left: 1440 } } },
    headers: { default: new Header({ children: [new Paragraph({ alignment: AlignmentType.RIGHT, children: [new TextRun({ text: "Offer Letter Kit 2026", size: 16, color: MUTED })] })] }) },
    footers: { default: new Footer({ children: [new Paragraph({
      tabStops: [{ type: TabStopType.RIGHT, position: CONTENT_W }],
      children: [new TextRun({ text: "Tech Hiring & Compensation Benchmark OS  |  Drafting aid, not legal advice", size: 16, color: MUTED }),
                 new TextRun({ text: "\tPage ", size: 16, color: MUTED }), new TextRun({ children: [PageNumber.CURRENT], size: 16, color: MUTED })] })] }) },
    children: [
      ...howTo, brk(), ...templateA, brk(), ...templateB, brk(), ...templateC, brk(), ...templateD, brk(),
      ...exhibit, brk(), ...approval, brk(), ...script, brk(), ...emails, brk(), ...review,
    ],
  }],
});

Packer.toBuffer(doc).then((buf) => { fs.writeFileSync(OUT, buf); console.log("saved", OUT); });
