# Tech Hiring OS - build scripts

Regenerates the three deliverables in products/tech-hiring-os/.

| Script | Output |
|---|---|
| build_xlsx.py | Hiring_OS_2026.xlsx |
| build_pdf.py (+ qbank_content.py) | Interview_Question_Bank.pdf |
| build_docx.js (+ strip_hcs.py) | Offer_Templates.docx |

## Setup
    python3 -m venv venv && ./venv/bin/pip install -r requirements.txt
    npm install

## Build (OUT = products/tech-hiring-os)
    ./venv/bin/python build_xlsx.py OUT/Hiring_OS_2026.xlsx
    # openpyxl writes formulas without values: open and save once in LibreOffice/Excel,
    # or recalc headless, before shipping.
    ./venv/bin/python build_pdf.py OUT/Interview_Question_Bank.pdf
    node build_docx.js OUT/Offer_Templates.docx
    ./venv/bin/python strip_hcs.py OUT/Offer_Templates.docx   # removes a non-schema tag docx-js emits

Question IDs in qbank_content.py must match the ranges cited in the workbook scorecards and Interview Loops sheet.
Run the sanitize-templates skill after rebuilding.
