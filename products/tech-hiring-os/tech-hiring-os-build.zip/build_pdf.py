"""Build Interview_Question_Bank.pdf."""
import sys
from xml.sax.saxutils import escape
from reportlab.lib.pagesizes import letter
from reportlab.lib.units import inch
from reportlab.lib import colors
from reportlab.lib.styles import ParagraphStyle
from reportlab.lib.enums import TA_LEFT
from reportlab.platypus import (BaseDocTemplate, PageTemplate, Frame, Paragraph, Spacer, Table, TableStyle,
                                PageBreak, NextPageTemplate, KeepTogether, CondPageBreak)
from reportlab.platypus.tableofcontents import TableOfContents
import qbank_content as C

OUT = sys.argv[1]
GROUPS = (C.CORE, C.ENG, C.PRD, C.SLS, C.LDR)
NQ = sum(len(c[5]) for g in GROUPS for c in g)
NC = sum(len(g) for g in GROUPS)
NCASE = len(C.ENG[1][5]) + sum(1 for g in GROUPS for c in g for q_, _ in c[5] if q_.startswith("Case:"))
NAVY = colors.HexColor("#1F2A44"); TEAL = colors.HexColor("#0F766E"); LIGHT = colors.HexColor("#EEF2F7")
MUTED = colors.HexColor("#6B7280"); LINE = colors.HexColor("#D1D5DB"); GREEN = colors.HexColor("#DCFCE7")
RED = colors.HexColor("#FEE2E2"); INK = colors.HexColor("#111827")
W, H = letter
M = 0.75 * inch
CW = W - 2 * M

ss = {
    "body": ParagraphStyle("body", fontName="Helvetica", fontSize=9.5, leading=13.5, textColor=INK),
    "small": ParagraphStyle("small", fontName="Helvetica", fontSize=8.5, leading=11.5, textColor=INK),
    "muted": ParagraphStyle("muted", fontName="Helvetica-Oblique", fontSize=8.5, leading=11.5, textColor=MUTED),
    "h1": ParagraphStyle("h1", fontName="Helvetica-Bold", fontSize=20, leading=24, textColor=NAVY, spaceAfter=6),
    "h2": ParagraphStyle("h2", fontName="Helvetica-Bold", fontSize=13, leading=17, textColor=TEAL, spaceBefore=10, spaceAfter=4),
    "h3": ParagraphStyle("h3", fontName="Helvetica-Bold", fontSize=10.5, leading=14, textColor=NAVY, spaceBefore=6, spaceAfter=2),
    "cell": ParagraphStyle("cell", fontName="Helvetica", fontSize=8.8, leading=11.8, textColor=INK),
    "cellb": ParagraphStyle("cellb", fontName="Helvetica-Bold", fontSize=8.8, leading=11.8, textColor=INK),
    "cellw": ParagraphStyle("cellw", fontName="Helvetica-Bold", fontSize=8.8, leading=11.8, textColor=colors.white),
    "probe": ParagraphStyle("probe", fontName="Helvetica-Oblique", fontSize=8.3, leading=11, textColor=colors.HexColor("#374151")),
    "bullet": ParagraphStyle("bullet", fontName="Helvetica", fontSize=9.5, leading=13.5, textColor=INK, leftIndent=12, bulletIndent=2),
    "comp": ParagraphStyle("comp", fontName="Helvetica-Bold", fontSize=11, leading=14, textColor=colors.white, backColor=NAVY,
                           borderPadding=6, leftIndent=6, rightIndent=0, spaceBefore=8, spaceAfter=12, keepWithNext=1),
    "toc1": ParagraphStyle("toc1", fontName="Helvetica-Bold", fontSize=10.5, leading=17, textColor=NAVY),
    "toc2": ParagraphStyle("toc2", fontName="Helvetica", fontSize=9.5, leading=14, leftIndent=16, textColor=INK),
}

def P(text, style="body", raw=False):
    return Paragraph(text if raw else escape(text), ss[style])

class Doc(BaseDocTemplate):
    def __init__(self, fn, **kw):
        super().__init__(fn, pagesize=letter, leftMargin=M, rightMargin=M, topMargin=M, bottomMargin=M,
                         title="Interview Question Bank 2026", author="Tech Hiring OS",
                         subject="Structured behavioural and technical interview questions for Engineering, Product and Sales", **kw)
        frame = Frame(M, M, CW, H - 2 * M, id="f")
        self.addPageTemplates([PageTemplate("cover", [frame], onPage=self.cover),
                               PageTemplate("body", [frame], onPage=self.chrome)])

    def afterFlowable(self, fl):
        if isinstance(fl, Paragraph) and hasattr(fl, "_toc"):
            lvl, text, key = fl._toc
            self.notify("TOCEntry", (lvl, text, self.page, key))
            self.canv.bookmarkPage(key)
            self.canv.addOutlineEntry(text, key, level=lvl, closed=lvl > 0)

    @staticmethod
    def cover(c, d):
        c.saveState()
        c.setFillColor(NAVY); c.rect(0, H * 0.42, W, H * 0.58, stroke=0, fill=1)
        c.setFillColor(TEAL); c.rect(0, H * 0.42 - 6, W, 6, stroke=0, fill=1)
        c.setFillColor(colors.white)
        c.setFont("Helvetica", 11); c.drawString(M, H - 1.4 * inch, "TECH HIRING & COMPENSATION BENCHMARK OS")
        c.setFont("Helvetica-Bold", 38); c.drawString(M, H - 2.4 * inch, "Interview")
        c.drawString(M, H - 2.95 * inch, "Question Bank")
        c.setFont("Helvetica", 15); c.drawString(M, H - 3.5 * inch, "2026 Edition")
        c.setFont("Helvetica", 11)
        c.drawString(M, H * 0.42 + 0.9 * inch, "Structured behavioural and technical questions, scoring rubrics,")
        c.drawString(M, H * 0.42 + 0.65 * inch, "case prompts and debrief guides for Engineering, Product and Sales.")
        c.setFillColor(NAVY); c.setFont("Helvetica-Bold", 11)
        y = H * 0.42 - 0.8 * inch
        stats = [(str(NQ), "questions with follow-up probes"), (str(NC), "competencies across 5 families"),
                 (str(NCASE), "design prompts & product cases"), ("1-4", "anchored scoring scale")]
        for i, (big, small) in enumerate(stats):
            x = M + i * (CW / 4)
            c.setFont("Helvetica-Bold", 22); c.setFillColor(TEAL); c.drawString(x, y, big)
            c.setFont("Helvetica", 8.5); c.setFillColor(INK); c.drawString(x, y - 14, small)
        c.setFont("Helvetica", 9); c.setFillColor(MUTED)
        c.drawString(M, 1.3 * inch, "Question IDs (e.g. ENG2.3) match the scorecards and interview loops in Hiring_OS_2026.xlsx.")
        c.drawString(M, 1.1 * inch, "Process guidance only. Not legal advice: confirm interview rules for each hiring jurisdiction.")
        c.restoreState()

    @staticmethod
    def chrome(c, d):
        c.saveState()
        c.setStrokeColor(LINE); c.setLineWidth(0.5)
        c.line(M, H - 0.55 * inch, W - M, H - 0.55 * inch)
        c.setFont("Helvetica", 7.5); c.setFillColor(MUTED)
        c.drawString(M, H - 0.48 * inch, "Interview Question Bank 2026")
        c.drawRightString(W - M, H - 0.48 * inch, "Tech Hiring & Compensation Benchmark OS")
        c.line(M, 0.55 * inch, W - M, 0.55 * inch)
        c.drawString(M, 0.4 * inch, "Use with Hiring_OS_2026.xlsx scorecards")
        c.drawRightString(W - M, 0.4 * inch, f"Page {d.page}")
        c.restoreState()

_k = [0]
def H1(text):
    _k[0] += 1
    p = P(text, "h1"); p._toc = (0, text, f"k{_k[0]}")
    return p

def H2(text, toc=True):
    p = P(text, "h2")
    if toc:
        _k[0] += 1; p._toc = (1, text, f"k{_k[0]}")
    return p

def grid(rows, widths, header=True, zebra=True, head_bg=NAVY, extra=None):
    t = Table(rows, colWidths=widths, repeatRows=1 if header else 0)
    st = [("VALIGN", (0, 0), (-1, -1), "TOP"), ("GRID", (0, 0), (-1, -1), 0.4, LINE),
          ("LEFTPADDING", (0, 0), (-1, -1), 5), ("RIGHTPADDING", (0, 0), (-1, -1), 5),
          ("TOPPADDING", (0, 0), (-1, -1), 4), ("BOTTOMPADDING", (0, 0), (-1, -1), 4)]
    if header:
        st.append(("BACKGROUND", (0, 0), (-1, 0), head_bg))
    if zebra:
        for i in range(1 if header else 0, len(rows)):
            if i % 2 == 0:
                st.append(("BACKGROUND", (0, i), (-1, i), colors.HexColor("#F9FAFB")))
    if extra:
        st += extra
    t.setStyle(TableStyle(st))
    return t

def hrow(*labels):
    return [P(l, "cellw") for l in labels]

def bullets(items, style="bullet"):
    return [Paragraph(escape(i), ss[style], bulletText="•") for i in items]

def competency(code, name, definition, strong, red, qs, note=None, heading=None):
    out = []
    sig = Table([[P("Strong signals", "cellb"), P("Red flags", "cellb")],
                 [[Paragraph(escape(s), ss["small"], bulletText="+") for s in strong],
                  [Paragraph(escape(s), ss["small"], bulletText="-") for s in red]]],
                colWidths=[CW / 2, CW / 2])
    sig.setStyle(TableStyle([("BACKGROUND", (0, 0), (0, -1), colors.HexColor("#F0FDF4")),
                             ("BACKGROUND", (1, 0), (1, -1), colors.HexColor("#FEF2F2")),
                             ("VALIGN", (0, 0), (-1, -1), "TOP"), ("BOX", (0, 0), (-1, -1), 0.4, LINE),
                             ("LINEAFTER", (0, 0), (0, -1), 0.4, LINE),
                             ("LEFTPADDING", (0, 0), (-1, -1), 7), ("TOPPADDING", (0, 0), (-1, -1), 3)]))
    head = ([heading] if heading else []) + [P(definition, "body"), Spacer(1, 5), sig, Spacer(1, 6)]
    rows = [hrow("ID", "Question", "Follow-up probes / what to look for")]
    for i, (qq, pr) in enumerate(qs, 1):
        rows.append([P(f"{code}.{i}", "cellb"), P(qq, "cell"), P(pr, "probe")])
    qt = grid(rows, [0.7 * inch, 3.55 * inch, CW - 4.25 * inch])
    out.append(KeepTogether(head + [qt]) if len(qs) <= 6 else KeepTogether(head))
    if len(qs) > 6:
        out.append(qt)
    if note:
        out += note
    out.append(Spacer(1, 14))
    return out

story = [NextPageTemplate("body"), PageBreak()]

# Contents
story.append(P("Contents", "h1"))
toc = TableOfContents()
toc.levelStyles = [ss["toc1"], ss["toc2"]]
toc.dotsMinLevel = 0
story += [toc, PageBreak()]

# Part 1
story.append(H1("1. How to use this question bank"))
story.append(P("Structured interviews predict job performance far better than unstructured conversations. "
               "Each interviewer owns two or three competencies, asks pre-selected questions from this bank, "
               "probes for evidence and scores against the same anchored scale. The scorecards in "
               "Hiring_OS_2026.xlsx list which question IDs to use for each stage."))
story.append(H2("Five rules for every interview"))
story += bullets([
    "Prepare: read the scorecard, pick two or three questions for your assigned competencies and decide your probes in advance.",
    "Ask for real examples: \"Tell me about a time...\" beats \"What would you do if...\". Use hypotheticals only for cases and design prompts.",
    "Probe until you have the full story: Situation, Task, Action and Result (STAR), with the candidate's own role made explicit.",
    "Take notes on evidence: what they said and did, in their words where possible.",
    "Score independently within 24 hours, before you see anyone else's feedback.",
])
story.append(H2("A 45-minute interview plan"))
story.append(grid([hrow("Minutes", "Block", "Notes"),
                   [P("0-5", "cell"), P("Welcome", "cellb"), P("Introduce yourself and the format. Set the candidate at ease.", "cell")],
                   [P("5-35", "cell"), P("Questions", "cellb"), P("Two or three questions with deep probing. Depth beats breadth: one fully explored example is worth five shallow ones.", "cell")],
                   [P("35-42", "cell"), P("Candidate questions", "cellb"), P("Answer honestly. Their questions are also signal.", "cell")],
                   [P("42-45", "cell"), P("Close", "cellb"), P("Explain next steps and timing. Do not hint at the outcome.", "cell")]],
                  [0.9 * inch, 1.4 * inch, CW - 2.3 * inch]))
story.append(H2("Scoring scale"))
rows = [hrow("Score", "Label", "Anchor")]
for s, l, a in C.SCALE:
    rows.append([P(s, "cellb"), P(l, "cellb"), P(a, "cell")])
story.append(grid(rows, [0.6 * inch, 1.0 * inch, CW - 1.6 * inch],
                  extra=[("BACKGROUND", (0, 1), (1, 2), GREEN), ("BACKGROUND", (0, 3), (1, 4), RED)]))
story.append(Spacer(1, 4))
story.append(P("Score against the bar for the level you are hiring for (L1-L5 in the workbook), not against the best person you have ever worked with.", "muted"))
story.append(H2("Probe library"))
story.append(P("Use these follow-ups with any behavioural question until you have specific, first-person evidence."))
rows = [hrow("Purpose", "Follow-up")]
for a, b in C.PROBES:
    rows.append([P(a, "cellb"), P(b, "cell")])
story.append(grid(rows, [1.2 * inch, CW - 1.2 * inch]))
story.append(PageBreak())

# Part 2
story.append(H1("2. Fair and lawful interviewing"))
story.append(P("Interview questions must relate to the job. Some topics are protected by anti-discrimination law in most jurisdictions "
               "and must never influence a decision, so do not ask about them, even casually over lunch. The table below covers "
               "common risks. Laws differ by country, state and city, so confirm the rules with your People team or counsel."))
story.append(H2("Topics to avoid and what to ask instead"))
rows = [hrow("Avoid asking about", "Job-related alternative")]
for a, b in C.LEGAL:
    rows.append([P(a, "cell"), P(b, "cell")])
story.append(grid(rows, [2.5 * inch, CW - 2.5 * inch]))
story.append(H2("Reducing bias in the loop"))
story += bullets(C.BIAS)
story.append(Spacer(1, 6))
story.append(P("If a candidate volunteers protected information, do not follow up on it, do not record it, and steer back to the job.", "muted"))
story.append(PageBreak())

# Part 3-7
def part(title_, intro, comps, extras=None):
    story.append(H1(title_))
    story.append(P(intro))
    story.append(Spacer(1, 8))
    for comp in comps:
        code, name, definition, strong, red, qs = comp
        story.append(CondPageBreak(2.5 * inch))
        _k[0] += 1
        hp = Paragraph(f'<font color="#5EEAD4">{code}</font>&nbsp;&nbsp;&nbsp;{escape(name)}', ss["comp"])
        hp._toc = (1, f"{code}  {name}", f"k{_k[0]}")
        story.extend(competency(code, name, definition, strong, red, qs, note=(extras or {}).get(code), heading=hp))
    story.append(PageBreak())

sd_rows = [hrow("Phase", "Time", "What good looks like"),
           ["Requirements & scope", "5-10 min", "Asks about users, scale, read/write mix, consistency and latency needs; writes them down"],
           ["Sizing", "3-5 min", "Back-of-envelope traffic, storage and bandwidth; uses numbers to drive design"],
           ["API & data model", "5-10 min", "Defines the key endpoints and entities before drawing boxes"],
           ["High-level design", "10 min", "Simple design that works first; explains each component's job"],
           ["Deep dive", "10-15 min", "Takes the hardest part deep: hot keys, consistency, fan-out, idempotency"],
           ["Failure & operations", "5 min", "Discusses failure modes, monitoring, deploys and rollback unprompted"]]
sd_rows = [sd_rows[0]] + [[P(a, "cellb"), P(b, "cell"), P(c, "cell")] for a, b, c in sd_rows[1:]]
cal = [hrow("Level", "Calibration"),
       [P("L2", "cellb"), P("A workable design with prompting; may need help with scale and failure modes.", "cell")],
       [P("L3", "cellb"), P("Drives the conversation; handles scale, data model and failure with light prompting.", "cell")],
       [P("L4+", "cellb"), P("Anticipates operational and organisational concerns, compares alternatives and describes how the design evolves.", "cell")]]
SD_NOTE = [Spacer(1, 6), KeepTogether([P("Running the system design interview (ENG2)", "h3"),
           grid(sd_rows, [1.6 * inch, 0.8 * inch, CW - 2.4 * inch]), Spacer(1, 6),
           grid(cal, [0.8 * inch, CW - 0.8 * inch])])]
cr = [hrow("Dimension", "Strong (4)", "Weak (1-2)")] + [[P(a, "cellb"), P(b, "cell"), P(c, "cell")] for a, b, c in C.CODING_RUBRIC]
CODE_NOTE = [Spacer(1, 6), KeepTogether([P("Coding / pairing exercise rubric (ENG3)", "h3"),
             P("Use a realistic, job-relevant problem the candidate can solve in 40 minutes in their own editor. "
               "Avoid trick puzzles. Allow documentation look-ups, as on the job.", "small"), Spacer(1, 4),
             grid(cr, [1.4 * inch, (CW - 1.4 * inch) / 2, (CW - 1.4 * inch) / 2])])]

part("3. Core competencies (all roles)",
     "Use these in every loop. Ownership, Collaboration and Communication are weighted on all three scorecards; "
     "Learning & growth and Judgment & integrity are optional extras for roles where they matter most.", C.CORE)
part("4. Engineering",
     "For software, ML, data, SRE and security engineers. ENG6 applies to Staff (L4) and above. "
     "Pair ENG2 prompts and the ENG3 exercise with the rubrics that follow them.",
     C.ENG, {"ENG2": SD_NOTE, "ENG3": CODE_NOTE})
part("5. Product",
     "For product managers, designers, researchers and data scientists. Cases are marked \"Case\": "
     "run them as 30-40 minute collaborative problems and score the thinking, not the final answer.", C.PRD)

rp = C.ROLEPLAY
rp_rows = [hrow("Dimension", "What a 4 looks like", "Score 1-4")] + [[P(a, "cellb"), P(b, "cell"), P("", "cell")] for a, b in rp["rubric"]]
RP_NOTE = [Spacer(1, 6), KeepTogether([P("Mock discovery call brief (SLS2.6)", "h3"), P(rp["setup"], "small"), Spacer(1, 4),
           P("Hidden information (interviewer only)", "cellb")] + bullets(rp["hidden"], "bullet") +
           [Spacer(1, 4), P("Interviewer instructions", "cellb")] + bullets(rp["instructions"], "bullet") +
           [Spacer(1, 6), grid(rp_rows, [1.5 * inch, CW - 2.3 * inch, 0.8 * inch])])]
part("6. Sales",
     "For SDRs, account executives, sales engineers, customer success and sales managers. "
     "Always verify claimed attainment through references or documentation before an offer.",
     C.SLS, {"SLS2": RP_NOTE})
story.pop()  # remove the page break after Sales so reference guide follows
story.append(KeepTogether([H2("Reference check guide"),
                           P("Run two references for every sales finalist, and for senior hires in any family, with the candidate's consent. "
                             "Ask open questions and listen for hesitation."),
                           Spacer(1, 4)] + bullets(C.REFERENCE_QS)))
story.append(PageBreak())
part("7. Leadership (manager roles)",
     "Add LDR competencies to any scorecard for manager roles (Engineering Manager, Group PM, Sales Manager and above). "
     "Set their weights on the scorecard and rebalance the others so the total is 100%.", C.LDR)

# Part 8
story.append(H1("8. Feedback, debrief and candidate experience"))
story.append(H2("Written feedback template"))
rows = [hrow("Section", "What to write")] + [[P(a, "cellb"), P(b, "cell")] for a, b in C.FEEDBACK_TEMPLATE]
story.append(grid(rows, [1.8 * inch, CW - 1.8 * inch]))
story.append(H2("Running the debrief"))
story += bullets(C.DEBRIEF)
story.append(H2("Candidate experience checklist"))
story += bullets(C.CANDIDATE_EXP)
story.append(Spacer(1, 16))
story.append(P("This guide is process guidance for structured hiring. It is not legal advice. Employment, privacy and "
               "pay-transparency rules vary by jurisdiction; have counsel review your process for each country you hire in.", "muted"))

doc = Doc(OUT)
doc.multiBuild(story)
print("saved", OUT, "questions:", NQ, "competencies:", NC, "cases:", NCASE)
