"""Build Hiring_OS_2026.xlsx — Tech Hiring & Compensation Benchmark OS."""
import datetime as dt
import sys
from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
from openpyxl.workbook.defined_name import DefinedName
from openpyxl.worksheet.datavalidation import DataValidation
from openpyxl.formatting.rule import FormulaRule, CellIsRule
from openpyxl.chart import BarChart, Reference
from openpyxl.comments import Comment

OUT = sys.argv[1]
F = "Arial"
NAVY, TEAL, LIGHT, INPUT_FILL, GREY = "1F2A44", "0F766E", "EEF2F7", "FFF2CC", "F3F4F6"

def font(**kw):
    base = dict(name=F, size=10)
    base.update(kw)
    return Font(**base)

thin = Side(style="thin", color="D1D5DB")
BORDER = Border(left=thin, right=thin, top=thin, bottom=thin)
HDR_FILL = PatternFill("solid", fgColor=NAVY)
SUB_FILL = PatternFill("solid", fgColor=LIGHT)
IN_FILL = PatternFill("solid", fgColor=INPUT_FILL)
WRAP = Alignment(wrap_text=True, vertical="top")
CENTER = Alignment(horizontal="center", vertical="center", wrap_text=True)

USD = '#,##0;(#,##0);"-"'
PCT = '0.0%;(0.0%);"-"'
PCT0 = '0%;(0%);"-"'
RATIO = '0.00;(0.00);"-"'
DATE = 'mmm d, yyyy'

wb = Workbook()
wb.remove(wb.active)

ORDER = ["README", "Dashboard", "Hiring Plan", "Band Calculator", "Comp Bands",
         "Salary Benchmarks", "Scorecard - Engineering", "Scorecard - Product",
         "Scorecard - Sales", "Interview Loops", "Offer Generator", "Offer Tracker",
         "Onboarding 30-60-90", "Settings"]
S = {n: wb.create_sheet(n) for n in ORDER}

def q(name):
    return f"'{name}'" if " " in name or "-" in name else name

def name(n, ref):
    wb.defined_names[n] = DefinedName(n, attr_text=ref)

def title(ws, text, sub=None):
    ws["A1"] = text
    ws["A1"].font = font(size=16, bold=True, color=NAVY)
    ws.row_dimensions[1].height = 26
    if sub:
        ws["A2"] = sub
        ws["A2"].font = font(size=9, italic=True, color="6B7280")
    ws.sheet_view.showGridLines = False

def header(ws, row, col, labels, fill=HDR_FILL, color="FFFFFF"):
    for i, lab in enumerate(labels):
        c = ws.cell(row=row, column=col + i, value=lab)
        c.font = font(bold=True, color=color)
        c.fill = fill
        c.alignment = CENTER
        c.border = BORDER
    ws.row_dimensions[row].height = 30

def section(ws, ref, text):
    ws[ref] = text
    ws[ref].font = font(size=12, bold=True, color=TEAL)

def cell(ws, ref, value, fmt=None, inp=False, bold=False, link=False, wrap=False, color=None):
    c = ws[ref]
    c.value = value
    col = color or ("0000FF" if inp else ("008000" if link else "000000"))
    c.font = font(bold=bold, color=col)
    if inp:
        c.fill = IN_FILL
    if fmt:
        c.number_format = fmt
    c.border = BORDER
    c.alignment = WRAP if wrap else Alignment(vertical="top")
    return c

def label(ws, ref, text, bold=False):
    c = ws[ref]
    c.value = text
    c.font = font(bold=bold)
    c.fill = SUB_FILL
    c.border = BORDER
    c.alignment = Alignment(vertical="top", wrap_text=True)
    return c

def widths(ws, d):
    for k, v in d.items():
        ws.column_dimensions[k].width = v

def dv_list(ws, formula, ref, prompt=None):
    dv = DataValidation(type="list", formula1=formula, allow_blank=True)
    if prompt:
        dv.promptTitle, dv.prompt = "Select", prompt
        dv.showInputMessage = True
    ws.add_data_validation(dv)
    dv.add(ref)

# ---------------------------------------------------------------- Settings
ws = S["Settings"]
title(ws, "Settings & Assumptions",
      "Every global input lives here. Blue text on yellow = edit me. All shipped values are illustrative samples.")
section(ws, "A3", "Company settings")
company = [
    ("Company name", "Northwind Labs", None, "CompanyName", "Sample company name. Replace with yours."),
    ("Plan year", 2026, "0", "PlanYear", None),
    ("Company stage", "Series B", None, "Stage", "Drives cash and equity factors (table at right)."),
    ("Market positioning (x market P50)", 1.0, "0.00x", "Positioning", "1.00 = pay at market median. 1.05 = lead market by 5%."),
    ("Band range spread (max/min - 1)", 0.40, PCT0, "Spread", "40% spread: min = mid / 1.2, max = min x 1.4."),
    ("Equity price per share (USD)", 3.20, '$#,##0.00', "SharePrice", "Use your latest 409A FMV (options) or preferred price (RSU value). Sample value."),
    ("Default vesting schedule", "4 years with a 1-year cliff, then monthly", None, "Vesting", None),
    ("Offer expiry (calendar days)", 5, "0", "ExpiryDays", None),
    ("Sign-on approval threshold (% of base)", 0.10, PCT0, "SignOnThreshold", "Sign-on above this share of base needs VP + Finance approval."),
    ("Equity approval threshold (x guideline)", 1.25, "0.00x", "EquityThreshold", "Equity above guideline x this factor needs approval."),
    ("Default pay frequency", "semi-monthly", None, "PayFreq", None),
]
for i, (lab, val, fmt, nm, note) in enumerate(company):
    r = 4 + i
    label(ws, f"A{r}", lab)
    c = cell(ws, f"B{r}", val, fmt, inp=True)
    if note:
        c.comment = Comment(note, "Hiring OS")
    name(nm, f"Settings!$B${r}")
r = 4 + len(company)
label(ws, f"A{r}", "Cash factor for stage (calc)")
cell(ws, f"B{r}", "=INDEX($E$5:$E$9,MATCH(Stage,$D$5:$D$9,0))", "0.00x")
name("CashFactor", f"Settings!$B${r}")
label(ws, f"A{r+1}", "Equity factor for stage (calc)")
cell(ws, f"B{r+1}", "=INDEX($F$5:$F$9,MATCH(Stage,$D$5:$D$9,0))", "0.00x")
name("EquityFactor", f"Settings!$B${r+1}")

section(ws, "D3", "Company stage factors")
header(ws, 4, 4, ["Stage", "Cash factor", "Equity factor", "Notes"])
stages = [("Seed", 0.85, 1.60, "Lower cash, larger equity grants"),
          ("Series A", 0.92, 1.30, ""),
          ("Series B", 0.97, 1.00, "Reference point"),
          ("Series C+", 1.00, 0.80, ""),
          ("Public", 1.05, 0.70, "Liquid RSUs, near-market cash")]
for i, (s, c1, c2, n) in enumerate(stages):
    rr = 5 + i
    cell(ws, f"D{rr}", s)
    cell(ws, f"E{rr}", c1, "0.00x", inp=True)
    cell(ws, f"F{rr}", c2, "0.00x", inp=True)
    cell(ws, f"G{rr}", n)
name("StageList", "Settings!$D$5:$D$9")
ws["D10"] = "Illustrative multipliers applied on top of market data. Calibrate to your investors' guidance."
ws["D10"].font = font(size=8, italic=True, color="6B7280")

section(ws, "D12", "Level framework")
header(ws, 13, 4, ["Level", "IC track", "Manager track", "Typical experience"])
levels = [("L1", "Associate / I", "-", "0-2 yrs"),
          ("L2", "Intermediate / II", "-", "2-5 yrs"),
          ("L3", "Senior", "Manager", "5-8 yrs"),
          ("L4", "Staff / Lead", "Senior Manager", "8-12 yrs"),
          ("L5", "Principal", "Director", "12+ yrs")]
for i, row in enumerate(levels):
    for j, v in enumerate(row):
        cell(ws, f"{'DEFG'[j]}{14+i}", v)
name("LevelList", "Settings!$D$14:$D$18")

# Locations
LOC_START = 22
section(ws, f"A{LOC_START-2}", "Locations, currency & employer cost")
header(ws, LOC_START - 1, 1, ["Location", "Region", "Currency", "Geo multiplier (vs US Tier 1, USD)",
                               "FX (local per 1 USD)", "Employer cost load %"])
locations = [
    ("US Tier 1 - SF Bay / NYC / Seattle", "North America", "USD", 1.00, 1.0, 0.25),
    ("US Tier 2 - Boston / LA / Austin / DC", "North America", "USD", 0.92, 1.0, 0.25),
    ("US Tier 3 - Other US / Remote US", "North America", "USD", 0.85, 1.0, 0.25),
    ("Canada - Toronto / Vancouver", "North America", "CAD", 0.62, 1.37, 0.18),
    ("UK - London", "Europe", "GBP", 0.60, 0.75, 0.20),
    ("UK - Rest of UK", "Europe", "GBP", 0.50, 0.75, 0.20),
    ("Ireland - Dublin", "Europe", "EUR", 0.55, 0.86, 0.15),
    ("Germany - Berlin / Munich", "Europe", "EUR", 0.52, 0.86, 0.22),
    ("Netherlands - Amsterdam", "Europe", "EUR", 0.55, 0.86, 0.20),
    ("France - Paris", "Europe", "EUR", 0.47, 0.86, 0.45),
    ("Spain - Madrid / Barcelona", "Europe", "EUR", 0.38, 0.86, 0.32),
    ("Portugal - Lisbon", "Europe", "EUR", 0.32, 0.86, 0.25),
    ("Poland - Warsaw / Krakow", "Europe", "PLN", 0.35, 3.65, 0.22),
    ("Israel - Tel Aviv", "Middle East", "ILS", 0.62, 3.40, 0.25),
    ("UAE - Dubai", "Middle East", "AED", 0.58, 3.6725, 0.12),
    ("India - Bengaluru", "Asia-Pacific", "INR", 0.24, 88.0, 0.15),
    ("Singapore", "Asia-Pacific", "SGD", 0.58, 1.29, 0.17),
    ("Australia - Sydney / Melbourne", "Asia-Pacific", "AUD", 0.58, 1.52, 0.20),
    ("Japan - Tokyo", "Asia-Pacific", "JPY", 0.45, 150.0, 0.16),
    ("Brazil - Sao Paulo", "Latin America", "BRL", 0.28, 5.40, 0.68),
    ("Mexico - Mexico City", "Latin America", "MXN", 0.30, 18.4, 0.35),
]
for i, (loc, reg, ccy, geo, fx, load) in enumerate(locations):
    rr = LOC_START + i
    cell(ws, f"A{rr}", loc)
    cell(ws, f"B{rr}", reg)
    cell(ws, f"C{rr}", ccy)
    cell(ws, f"D{rr}", geo, "0.00", inp=True)
    cell(ws, f"E{rr}", fx, "#,##0.00##", inp=True)
    cell(ws, f"F{rr}", load, PCT0, inp=True)
LOC_END = LOC_START + len(locations) - 1
for nm, col in [("LocList", "A"), ("LocCcy", "C"), ("LocGeo", "D"), ("LocFX", "E"), ("LocLoad", "F")]:
    name(nm, f"Settings!${col}${LOC_START}:${col}${LOC_END}")
note_r = LOC_END + 1
ws[f"A{note_r}"] = ("Geo multipliers, FX rates and employer-cost loads are illustrative planning estimates, not quotes. "
                    "Refresh FX monthly and confirm employer costs with payroll or your Employer of Record.")
ws[f"A{note_r}"].font = font(size=8, italic=True, color="6B7280")

# Lists
section(ws, "H20", "Dropdown lists")
lists = {
    "H": ("Families", ["Engineering", "Product", "Sales"], "FamilyList"),
    "I": ("Req status", ["Open", "Interviewing", "Offer out", "Filled", "On hold"], "ReqStatus"),
    "J": ("Offer status", ["Draft", "Pending approval", "Sent", "Accepted", "Declined", "Rescinded"], "OfferStatus"),
    "K": ("Task status", ["Not started", "In progress", "Done", "Blocked"], "TaskStatus"),
    "L": ("Yes / No", ["Yes", "No"], "YesNo"),
    "M": ("Priority", ["P1", "P2", "P3"], "PriorityList"),
    "N": ("Equity type", ["stock options", "restricted stock units (RSUs)"], "EquityTypeList"),
    "O": ("Decline reason", ["Compensation", "Competing offer", "Counter-offer", "Role scope", "Location / remote",
                             "Personal", "Process too slow", "Other"], "DeclineList"),
}
for col, (hdr, vals, nm) in lists.items():
    header(ws, 21, ord(col) - 64, [hdr])
    for i, v in enumerate(vals):
        cell(ws, f"{col}{22+i}", v)
    name(nm, f"Settings!${col}$22:${col}${21+len(vals)}")
widths(ws, {"A": 40, "B": 34, "C": 11, "D": 20, "E": 16, "F": 16, "G": 28,
            "H": 14, "I": 14, "J": 17, "K": 13, "L": 9, "M": 9, "N": 26, "O": 18})
dv_list(ws, "=StageList", "B6")
ws.freeze_panes = "A4"

# --------------------------------------------------------- Salary Benchmarks
ws = S["Salary Benchmarks"]
title(ws, "Global Tech Salary Benchmarks - 2026",
      "Annual base salary, USD, US Tier 1 reference market. Other locations are derived on Comp Bands via Settings multipliers.")
BM_HDR = 4
header(ws, BM_HDR, 1, ["Lookup key", "Family", "Role", "Level", "Job title", "Market P25 (USD)", "Market P50 (USD)",
                        "Market P75 (USD)", "Target bonus % of base", "Base share of OTE",
                        "Annual equity guideline (% of base)", "Notes"])

def ladder(family, role, titles, p50k, bonus, share, equity, levels=("L1", "L2", "L3", "L4", "L5"), note=""):
    out = []
    for lv, t, p, b, e in zip(levels, titles, p50k, bonus, equity):
        out.append((family, role, lv, t, p * 1000, b, share, e, note))
    return out

IC_B = [0, 0, 0.05, 0.08, 0.10]
data = []
data += ladder("Engineering", "Software Engineer",
               ["Software Engineer I", "Software Engineer II", "Senior Software Engineer", "Staff Software Engineer", "Principal Software Engineer"],
               [135, 165, 200, 245, 290], IC_B, 1, [0.12, 0.18, 0.28, 0.45, 0.65], note="Backend, frontend and full-stack")
data += ladder("Engineering", "Machine Learning Engineer",
               ["ML Engineer I", "ML Engineer II", "Senior ML Engineer", "Staff ML Engineer", "Principal ML Engineer"],
               [150, 185, 230, 285, 340], IC_B, 1, [0.14, 0.21, 0.32, 0.52, 0.75], note="Includes applied AI / LLM engineering")
data += ladder("Engineering", "Data Engineer",
               ["Data Engineer I", "Data Engineer II", "Senior Data Engineer", "Staff Data Engineer", "Principal Data Engineer"],
               [130, 158, 190, 230, 270], IC_B, 1, [0.12, 0.17, 0.26, 0.42, 0.60])
data += ladder("Engineering", "Site Reliability / DevOps Engineer",
               ["SRE I", "SRE II", "Senior SRE", "Staff SRE", "Principal SRE"],
               [130, 160, 192, 232, 272], IC_B, 1, [0.12, 0.17, 0.26, 0.42, 0.60], note="Platform, infrastructure, DevOps")
data += ladder("Engineering", "Security Engineer",
               ["Security Engineer I", "Security Engineer II", "Senior Security Engineer", "Staff Security Engineer", "Principal Security Engineer"],
               [135, 165, 198, 240, 282], IC_B, 1, [0.12, 0.18, 0.27, 0.44, 0.62])
data += ladder("Engineering", "Engineering Manager",
               ["Engineering Manager", "Senior Engineering Manager", "Director of Engineering"],
               [215, 250, 295], [0.10, 0.12, 0.15], 1, [0.35, 0.50, 0.70], levels=("L3", "L4", "L5"),
               note="Manager track starts at L3")
data += ladder("Product", "Product Manager",
               ["Associate Product Manager", "Product Manager", "Senior Product Manager", "Group Product Manager", "Director of Product"],
               [130, 158, 190, 228, 268], [0, 0, 0.05, 0.10, 0.15], 1, [0.12, 0.18, 0.28, 0.42, 0.60])
data += ladder("Product", "Product Designer",
               ["Product Designer I", "Product Designer II", "Senior Product Designer", "Staff Product Designer", "Principal Product Designer"],
               [110, 138, 168, 200, 235], IC_B, 1, [0.10, 0.15, 0.24, 0.36, 0.52], note="UX / UI / product design")
data += ladder("Product", "UX Researcher",
               ["UX Researcher I", "UX Researcher II", "Senior UX Researcher", "Staff UX Researcher", "Principal UX Researcher"],
               [105, 130, 158, 188, 220], IC_B, 1, [0.10, 0.14, 0.22, 0.32, 0.45])
data += ladder("Product", "Data Scientist",
               ["Data Scientist I", "Data Scientist II", "Senior Data Scientist", "Staff Data Scientist", "Principal Data Scientist"],
               [120, 148, 180, 215, 252], IC_B, 1, [0.12, 0.18, 0.27, 0.40, 0.58], note="Product analytics & experimentation")
data += ladder("Sales", "Sales Development Rep",
               ["Sales Development Representative", "Senior SDR", "SDR Team Lead"],
               [64, 74, 88], [0, 0, 0], 0.70, [0.05, 0.06, 0.08], levels=("L1", "L2", "L3"), note="Base shown; OTE = base / base share")
data += ladder("Sales", "Account Executive",
               ["Account Executive, SMB", "Account Executive, Mid-Market", "Enterprise Account Executive", "Strategic Account Executive"],
               [78, 108, 150, 178], [0, 0, 0, 0], 0.50, [0.10, 0.12, 0.15, 0.18], levels=("L1", "L2", "L3", "L4"), note="50/50 split is typical")
data += ladder("Sales", "Sales Engineer",
               ["Sales Engineer I", "Sales Engineer II", "Senior Sales Engineer", "Principal Sales Engineer"],
               [118, 142, 168, 198], [0, 0, 0, 0], 0.75, [0.12, 0.15, 0.20, 0.28], levels=("L1", "L2", "L3", "L4"), note="Pre-sales / solutions")
data += ladder("Sales", "Customer Success Manager",
               ["Customer Success Manager I", "Customer Success Manager II", "Senior Customer Success Manager", "Strategic Customer Success Manager"],
               [78, 98, 122, 145], [0, 0, 0, 0], 0.85, [0.08, 0.10, 0.14, 0.18], levels=("L1", "L2", "L3", "L4"))
data += ladder("Sales", "Sales Manager",
               ["Sales Manager", "Senior Sales Manager", "Director of Sales"],
               [165, 195, 235], [0, 0, 0], 0.60, [0.20, 0.28, 0.40], levels=("L3", "L4", "L5"), note="Manager track starts at L3")

BM_START = BM_HDR + 1
for i, (fam, role, lv, t, p50, b, share, e, note) in enumerate(data):
    rr = BM_START + i
    cell(ws, f"A{rr}", f'=C{rr}&"|"&D{rr}', color="6B7280")
    cell(ws, f"B{rr}", fam)
    cell(ws, f"C{rr}", role)
    cell(ws, f"D{rr}", lv)
    cell(ws, f"E{rr}", t)
    cell(ws, f"F{rr}", round(p50 * 0.90, -3), USD, inp=True)
    cell(ws, f"G{rr}", p50, USD, inp=True)
    cell(ws, f"H{rr}", round(p50 * 1.13, -3), USD, inp=True)
    cell(ws, f"I{rr}", b, PCT0, inp=True)
    cell(ws, f"J{rr}", share, PCT0, inp=True)
    cell(ws, f"K{rr}", e, PCT0, inp=True)
    cell(ws, f"L{rr}", note)
BM_END = BM_START + len(data) - 1
for nm, col in [("BM_Key", "A"), ("BM_Family", "B"), ("BM_Role", "C"), ("BM_Level", "D"), ("BM_Title", "E"),
                ("BM_P25", "F"), ("BM_P50", "G"), ("BM_P75", "H"), ("BM_Bonus", "I"), ("BM_BaseShare", "J"),
                ("BM_Equity", "K")]:
    name(nm, f"{q('Salary Benchmarks')}!${col}${BM_START}:${col}${BM_END}")
src = BM_END + 2
ws[f"A{src}"] = "Source & method"
ws[f"A{src}"].font = font(bold=True)
ws[f"A{src+1}"] = ("Illustrative 2026 planning estimates compiled for this template from publicly discussed market ranges for venture-backed "
                   "tech companies. They are not survey data. Replace the blue cells with your licensed survey cut "
                   "(e.g. Pave, Carta Total Compensation, Radford/Aon, Ravio) before making live offers.")
ws[f"A{src+2}"] = ("Sales rows show BASE salary. On-target earnings (OTE) = base / base share of OTE. "
                   "Equity guideline = annual grant value as % of base at a Series B company; Settings applies the stage factor.")
for r_ in (src + 1, src + 2):
    ws[f"A{r_}"].font = font(size=9, italic=True, color="374151")
widths(ws, {"A": 34, "B": 13, "C": 32, "D": 7, "E": 36, "F": 15, "G": 15, "H": 15, "I": 13, "J": 12, "K": 15, "L": 38})
ws.column_dimensions["A"].hidden = False
ws.freeze_panes = f"F{BM_START}"
ws.auto_filter.ref = f"A{BM_HDR}:L{BM_END}"

# Role list on Settings (unique, in benchmark order)
ws_set = S["Settings"]
roles = []
for d in data:
    if d[1] not in roles:
        roles.append(d[1])
header(ws_set, 21, 17, ["Role list (auto)"])
for i, rname in enumerate(roles):
    cell(ws_set, f"Q{22+i}", rname)
name("RoleList", f"Settings!$Q$22:$Q${21+len(roles)}")
ws_set.column_dimensions["Q"].width = 32

def bm(col_name, key):
    return f"INDEX({col_name},MATCH({key},BM_Key,0))"

def loc(col_name, ref):
    return f"INDEX({col_name},MATCH({ref},LocList,0))"

# ---------------------------------------------------------- Band Calculator
ws = S["Band Calculator"]
title(ws, "Compensation Band Calculator",
      "Pick a role, level and location, enter a proposed base. Everything else is calculated.")
section(ws, "B3", "Inputs")
inputs = [("Role", "Software Engineer", None, "=RoleList"),
          ("Level", "L3", None, "=LevelList"),
          ("Location", "UK - London", None, "=LocList"),
          ("Proposed base salary (local currency)", 92000, USD, None),
          ("Candidate's current base (local, optional)", 82000, USD, None),
          ("Sign-on bonus (local, optional)", 5000, USD, None)]
for i, (lab, val, fmt, lst) in enumerate(inputs):
    rr = 4 + i
    label(ws, f"B{rr}", lab)
    cell(ws, f"C{rr}", val, fmt, inp=True)
    if lst:
        dv_list(ws, lst, f"C{rr}")
KEY = '$C$4&"|"&$C$5'
section(ws, "B11", "Lookups")
lk = [("Benchmark row found?", f'=IF(ISNUMBER(MATCH({KEY},BM_Key,0)),"Yes","No - level not offered for this role")', None),
      ("Job title", f'=IFERROR({bm("BM_Title", KEY)},"")', None),
      ("Family", f'=IFERROR({bm("BM_Family", KEY)},"")', None),
      ("Local currency", f'={loc("LocCcy", "$C$6")}', None),
      ("Geo multiplier", f'={loc("LocGeo", "$C$6")}', "0.00"),
      ("FX (local per USD)", f'={loc("LocFX", "$C$6")}', "#,##0.00##"),
      ("Company stage / cash factor", '=Stage&" / "&TEXT(CashFactor,"0.00")&"x"', None),
      ("Employer cost load", f'={loc("LocLoad", "$C$6")}', PCT0)]
for i, (lab, f_, fmt) in enumerate(lk):
    rr = 12 + i
    label(ws, f"B{rr}", lab)
    cell(ws, f"C{rr}", f_, fmt)
# rows 12..19 ; C15 ccy, C16 geo, C17 fx, C19 load
section(ws, "B21", "Market & band")
header(ws, 22, 2, ["Metric", "Local currency", "USD equivalent"])
G = "IF($C$12<>\"Yes\",\"\","
rows_mb = [
    ("Market P25", f'={G}{bm("BM_P25", KEY)}*$C$16*$C$17*CashFactor)'),
    ("Market P50", f'={G}{bm("BM_P50", KEY)}*$C$16*$C$17*CashFactor)'),
    ("Market P75", f'={G}{bm("BM_P75", KEY)}*$C$16*$C$17*CashFactor)'),
    ("Band minimum", f'={G}C27/(1+Spread/2))'),
    ("Band midpoint", f'={G}C24*Positioning)'),
    ("Band maximum", f'={G}C26*(1+Spread))'),
]
for i, (lab, f_) in enumerate(rows_mb):
    rr = 23 + i
    label(ws, f"B{rr}", lab, bold=lab.startswith("Band"))
    cell(ws, f"C{rr}", f_, USD, bold=lab.startswith("Band"))
    cell(ws, f"D{rr}", f'=IF(C{rr}="","",C{rr}/$C$17)', USD)
# 23 P25, 24 P50, 25 P75, 26 min, 27 mid, 28 max
section(ws, "B30", "Offer analysis")
header(ws, 31, 2, ["Metric", "Value", "How to read it"])
oa = [
    ("Compa-ratio (proposed / midpoint)", '=IFERROR($C$7/$C$27,"")', RATIO, "0.90-1.10 is the normal hiring zone"),
    ("Range penetration", '=IFERROR(($C$7-$C$26)/($C$28-$C$26),"")', PCT0, "0% = band min, 100% = band max"),
    ("Band status", '=IF($C$27="","",IF($C$7<$C$26,"Below band",IF($C$7>$C$28,"Above band - needs approval","Within band")))', None, "Above band routes to VP + Finance"),
    ("Increase vs current base", '=IFERROR(IF($C$8>0,$C$7/$C$8-1,""),"")', PCT, "Typical external move: 10-25%"),
    ("Target bonus %", f'=IFERROR({bm("BM_Bonus", KEY)},"")', PCT0, "From Salary Benchmarks"),
    ("Target bonus (local)", '=IFERROR($C$7*$C$36,"")', USD, ""),
    ("On-target earnings (sales only)", f'=IFERROR(IF({bm("BM_BaseShare", KEY)}<1,$C$7/{bm("BM_BaseShare", KEY)},""),"")', USD, "Base / base share of OTE"),
    ("Variable at target (sales only)", '=IFERROR(IF($C$38="","",$C$38-$C$7),"")', USD, ""),
    ("Equity guideline, annual value (local)", f'=IFERROR($C$7*{bm("BM_Equity", KEY)}*EquityFactor,"")', USD, "Includes stage equity factor"),
    ("Equity guideline, 4-year grant (USD)", '=IFERROR($C$40/$C$17*4,"")', USD, ""),
    ("Equity guideline, units", '=IFERROR(ROUND($C$41/SharePrice,-2),"")', "#,##0", "At Settings price per share"),
    ("Year-1 total compensation (local)", '=IFERROR($C$7+N($C$37)+N($C$39)+$C$40+$C$9,"")', USD, "Base + bonus/variable + 1/4 equity + sign-on"),
    ("Employer annual cost (local)", '=IFERROR($C$7*(1+$C$19)+N($C$37)+N($C$39),"")', USD, "Base + employer load + bonus/variable"),
]
for i, (lab, f_, fmt, how) in enumerate(oa):
    rr = 32 + i
    label(ws, f"B{rr}", lab)
    cell(ws, f"C{rr}", f_, fmt, bold=(lab == "Band status"))
    cell(ws, f"D{rr}", how, color="6B7280")
# 32 compa,33 pen,34 status,35 incr,36 bonus%,37 bonus,38 OTE,39 var,40 eq annual,41 eq4yr,42 units,43 Y1,44 cost
ws.conditional_formatting.add("C34", FormulaRule(formula=['LEFT($C$34,5)="Above"'], fill=PatternFill("solid", fgColor="FEE2E2"), font=Font(name=F, bold=True, color="B91C1C")))
ws.conditional_formatting.add("C34", FormulaRule(formula=['$C$34="Below band"'], fill=PatternFill("solid", fgColor="FEF3C7"), font=Font(name=F, bold=True, color="92400E")))
ws.conditional_formatting.add("C34", FormulaRule(formula=['$C$34="Within band"'], fill=PatternFill("solid", fgColor="DCFCE7"), font=Font(name=F, bold=True, color="166534")))
ws.conditional_formatting.add("C12", FormulaRule(formula=['$C$12<>"Yes"'], font=Font(name=F, bold=True, color="B91C1C")))
widths(ws, {"A": 2, "B": 42, "C": 24, "D": 40})

# ---------------------------------------------------------- Comp Bands
ws = S["Comp Bands"]
title(ws, "Compensation Bands by Location",
      "Choose a location; every role and level re-prices into local currency using Settings (stage, positioning, spread).")
label(ws, "B4", "Location")
cell(ws, "C4", "US Tier 1 - SF Bay / NYC / Seattle", inp=True)
dv_list(ws, "=LocList", "C4")
label(ws, "B5", "Currency"); cell(ws, "C5", f'={loc("LocCcy", "$C$4")}')
label(ws, "B6", "Geo multiplier"); cell(ws, "C6", f'={loc("LocGeo", "$C$4")}', "0.00")
label(ws, "B7", "FX (local per USD)"); cell(ws, "C7", f'={loc("LocFX", "$C$4")}', "#,##0.00##")
label(ws, "E4", "Stage"); cell(ws, "F4", "=Stage", link=True)
label(ws, "E5", "Positioning"); cell(ws, "F5", "=Positioning", "0.00x", link=True)
label(ws, "E6", "Range spread"); cell(ws, "F6", "=Spread", PCT0, link=True)
CB_HDR = 9
header(ws, CB_HDR, 1, ["Family", "Role", "Level", "Job title", "Band min", "Band midpoint", "Band max",
                       "OTE at midpoint (sales)", "Target bonus %", "Equity guideline / yr (local)"])
SB = q("Salary Benchmarks")
for i in range(len(data)):
    rr = CB_HDR + 1 + i
    br = BM_START + i
    cell(ws, f"A{rr}", f"={SB}!B{br}", link=True)
    cell(ws, f"B{rr}", f"={SB}!C{br}", link=True)
    cell(ws, f"C{rr}", f"={SB}!D{br}", link=True)
    cell(ws, f"D{rr}", f"={SB}!E{br}", link=True)
    cell(ws, f"F{rr}", f"={SB}!G{br}*$C$6*$C$7*CashFactor*Positioning", USD, bold=True)
    cell(ws, f"E{rr}", f"=F{rr}/(1+Spread/2)", USD)
    cell(ws, f"G{rr}", f"=E{rr}*(1+Spread)", USD)
    cell(ws, f"H{rr}", f'=IF({SB}!J{br}<1,F{rr}/{SB}!J{br},"")', USD)
    cell(ws, f"I{rr}", f"={SB}!I{br}", PCT0, link=True)
    cell(ws, f"J{rr}", f"=F{rr}*{SB}!K{br}*EquityFactor", USD)
CB_END = CB_HDR + len(data)
ws.conditional_formatting.add(f"A{CB_HDR+1}:J{CB_END}", FormulaRule(formula=[f'$A{CB_HDR+1}="Product"'], fill=PatternFill("solid", fgColor="F0F9FF")))
ws.conditional_formatting.add(f"A{CB_HDR+1}:J{CB_END}", FormulaRule(formula=[f'$A{CB_HDR+1}="Sales"'], fill=PatternFill("solid", fgColor="F0FDF4")))
widths(ws, {"A": 13, "B": 32, "C": 7, "D": 36, "E": 14, "F": 15, "G": 14, "H": 16, "I": 11, "J": 17})
ws.freeze_panes = f"E{CB_HDR+1}"
ws.auto_filter.ref = f"A{CB_HDR}:J{CB_END}"

# ---------------------------------------------------------- Hiring Plan
ws = S["Hiring Plan"]
title(ws, "Hiring Plan & Headcount Budget",
      "One row per requisition. Budget = band midpoint for the role, level and location, plus employer load and target bonus/variable.")
HP_HDR, HP_START, HP_END = 6, 7, 56
header(ws, HP_HDR, 1, ["Req ID", "Role", "Level", "Location", "Department", "Hiring manager", "Target start",
                       "Priority", "Status", "Currency", "Budgeted base (local)", "Budgeted base (USD)",
                       "Annual loaded cost (USD)", "Plan-year cost (USD)", "Notes"])
reqs = [
    ("ENG-101", "Software Engineer", "L3", "US Tier 1 - SF Bay / NYC / Seattle", "A. Morgan", dt.date(2026, 2, 2), "P1", "Filled"),
    ("ENG-102", "Software Engineer", "L2", "Poland - Warsaw / Krakow", "A. Morgan", dt.date(2026, 3, 16), "P1", "Filled"),
    ("ENG-103", "Machine Learning Engineer", "L4", "US Tier 2 - Boston / LA / Austin / DC", "A. Morgan", dt.date(2026, 6, 1), "P1", "Offer out"),
    ("ENG-104", "Site Reliability / DevOps Engineer", "L3", "Germany - Berlin / Munich", "R. Chen", dt.date(2026, 7, 1), "P2", "Interviewing"),
    ("ENG-105", "Engineering Manager", "L3", "UK - London", "R. Chen", dt.date(2026, 9, 1), "P2", "Open"),
    ("ENG-106", "Data Engineer", "L2", "India - Bengaluru", "R. Chen", dt.date(2026, 10, 1), "P3", "Open"),
    ("PRD-201", "Product Manager", "L3", "US Tier 1 - SF Bay / NYC / Seattle", "D. Okafor", dt.date(2026, 4, 1), "P1", "Filled"),
    ("PRD-202", "Product Designer", "L3", "Canada - Toronto / Vancouver", "D. Okafor", dt.date(2026, 6, 15), "P2", "Interviewing"),
    ("PRD-203", "Data Scientist", "L2", "Spain - Madrid / Barcelona", "D. Okafor", dt.date(2026, 11, 2), "P3", "On hold"),
    ("SLS-301", "Account Executive", "L3", "US Tier 2 - Boston / LA / Austin / DC", "P. Novak", dt.date(2026, 3, 2), "P1", "Filled"),
    ("SLS-302", "Sales Development Rep", "L1", "US Tier 3 - Other US / Remote US", "P. Novak", dt.date(2026, 5, 4), "P1", "Offer out"),
    ("SLS-303", "Sales Engineer", "L2", "UK - London", "P. Novak", dt.date(2026, 8, 3), "P2", "Interviewing"),
    ("SLS-304", "Customer Success Manager", "L2", "Netherlands - Amsterdam", "P. Novak", dt.date(2026, 9, 14), "P2", "Open"),
]
for i in range(HP_END - HP_START + 1):
    rr = HP_START + i
    k = f'$B{rr}&"|"&$C{rr}'
    vals = reqs[i] if i < len(reqs) else (None,) * 8
    for col, v, fmt in zip("ABCDFGHI", vals, [None, None, None, None, None, DATE, None, None]):
        cell(ws, f"{col}{rr}", v, fmt, inp=True)
    cell(ws, f"E{rr}", f'=IFERROR({bm("BM_Family", k)},"")')
    cell(ws, f"J{rr}", f'=IFERROR({loc("LocCcy", f"$D{rr}")},"")')
    cell(ws, f"L{rr}", f'=IFERROR({bm("BM_P50", k)}*{loc("LocGeo", f"$D{rr}")}*CashFactor*Positioning,"")', USD)
    cell(ws, f"K{rr}", f'=IFERROR(L{rr}*{loc("LocFX", f"$D{rr}")},"")', USD)
    cell(ws, f"M{rr}", f'=IFERROR(L{rr}*(1+{loc("LocLoad", f"$D{rr}")})+L{rr}*{bm("BM_Bonus", k)}+L{rr}*(1/{bm("BM_BaseShare", k)}-1),"")', USD)
    cell(ws, f"N{rr}", f'=IF(OR(M{rr}="",G{rr}=""),"",IF(YEAR(G{rr})>PlanYear,0,IF(YEAR(G{rr})<PlanYear,M{rr},M{rr}*(13-MONTH(G{rr}))/12)))', USD)
    cell(ws, f"O{rr}", None, inp=True)
dv_list(ws, "=RoleList", f"B{HP_START}:B{HP_END}")
dv_list(ws, "=LevelList", f"C{HP_START}:C{HP_END}")
dv_list(ws, "=LocList", f"D{HP_START}:D{HP_END}")
dv_list(ws, "=PriorityList", f"H{HP_START}:H{HP_END}")
dv_list(ws, "=ReqStatus", f"I{HP_START}:I{HP_END}")
label(ws, "A4", "Total reqs", bold=True)
cell(ws, "B4", f'=COUNTA(A{HP_START}:A{HP_END})', "0", bold=True)
label(ws, "D4", "Plan-year cost (USD)", bold=True)
cell(ws, "E4", f"=SUM(N{HP_START}:N{HP_END})", USD, bold=True)
label(ws, "G4", "Annual run-rate (USD)", bold=True)
cell(ws, "H4", f"=SUM(M{HP_START}:M{HP_END})", USD, bold=True)
ws.conditional_formatting.add(f"I{HP_START}:I{HP_END}", CellIsRule(operator="equal", formula=['"Filled"'], fill=PatternFill("solid", fgColor="DCFCE7")))
ws.conditional_formatting.add(f"I{HP_START}:I{HP_END}", CellIsRule(operator="equal", formula=['"Offer out"'], fill=PatternFill("solid", fgColor="DBEAFE")))
ws.conditional_formatting.add(f"I{HP_START}:I{HP_END}", CellIsRule(operator="equal", formula=['"On hold"'], fill=PatternFill("solid", fgColor=GREY)))
widths(ws, {"A": 10, "B": 30, "C": 7, "D": 34, "E": 13, "F": 15, "G": 13, "H": 9, "I": 13, "J": 9,
            "K": 15, "L": 15, "M": 16, "N": 16, "O": 28})
ws.freeze_panes = f"C{HP_START}"

# ---------------------------------------------------------- Offer Tracker
ws = S["Offer Tracker"]
title(ws, "Offer Tracker",
      "Log every offer. Band position, expiry and time-to-decision calculate automatically and feed the Dashboard.")
OT_HDR, OT_START, OT_END = 5, 6, 55
header(ws, OT_HDR, 1, ["Candidate", "Req ID", "Role", "Level", "Location", "Currency", "Offered base (local)",
                       "Band midpoint (local)", "Compa-ratio", "Band status", "Sign-on (local)", "Equity units",
                       "Offer sent", "Expires", "Status", "Decision date", "Days to decision", "Decline reason", "Notes"])
offers = [
    ("Candidate A", "ENG-101", "Software Engineer", "L3", "US Tier 1 - SF Bay / NYC / Seattle", 198000, 10000, 68000, dt.date(2026, 1, 5), "Accepted", dt.date(2026, 1, 8), None),
    ("Candidate B", "ENG-102", "Software Engineer", "L2", "Poland - Warsaw / Krakow", 205000, 0, 12000, dt.date(2026, 2, 9), "Accepted", dt.date(2026, 2, 13), None),
    ("Candidate C", "PRD-201", "Product Manager", "L3", "US Tier 1 - SF Bay / NYC / Seattle", 186000, 0, 60000, dt.date(2026, 2, 23), "Declined", dt.date(2026, 2, 27), "Competing offer"),
    ("Candidate D", "PRD-201", "Product Manager", "L3", "US Tier 1 - SF Bay / NYC / Seattle", 192000, 15000, 62000, dt.date(2026, 3, 9), "Accepted", dt.date(2026, 3, 11), None),
    ("Candidate E", "SLS-301", "Account Executive", "L3", "US Tier 2 - Boston / LA / Austin / DC", 140000, 0, 26000, dt.date(2026, 1, 26), "Accepted", dt.date(2026, 1, 29), None),
    ("Candidate F", "ENG-103", "Machine Learning Engineer", "L4", "US Tier 2 - Boston / LA / Austin / DC", 285000, 25000, 185000, dt.date(2026, 10, 12), "Pending approval", None, None),
    ("Candidate G", "SLS-302", "Sales Development Rep", "L1", "US Tier 3 - Other US / Remote US", 54000, 0, 3500, dt.date(2026, 10, 15), "Sent", None, None),
]
for i in range(OT_END - OT_START + 1):
    rr = OT_START + i
    k = f'$C{rr}&"|"&$D{rr}'
    o = offers[i] if i < len(offers) else (None,) * 12
    cell(ws, f"A{rr}", o[0], inp=True); cell(ws, f"B{rr}", o[1], inp=True); cell(ws, f"C{rr}", o[2], inp=True)
    cell(ws, f"D{rr}", o[3], inp=True); cell(ws, f"E{rr}", o[4], inp=True)
    cell(ws, f"G{rr}", o[5], USD, inp=True); cell(ws, f"K{rr}", o[6], USD, inp=True); cell(ws, f"L{rr}", o[7], "#,##0", inp=True)
    cell(ws, f"M{rr}", o[8], DATE, inp=True); cell(ws, f"O{rr}", o[9], inp=True); cell(ws, f"P{rr}", o[10], DATE, inp=True)
    cell(ws, f"R{rr}", o[11], inp=True); cell(ws, f"S{rr}", None, inp=True)
    cell(ws, f"F{rr}", f'=IFERROR({loc("LocCcy", f"$E{rr}")},"")')
    cell(ws, f"H{rr}", f'=IFERROR({bm("BM_P50", k)}*{loc("LocGeo", f"$E{rr}")}*{loc("LocFX", f"$E{rr}")}*CashFactor*Positioning,"")', USD)
    cell(ws, f"I{rr}", f'=IFERROR(G{rr}/H{rr},"")', RATIO)
    cell(ws, f"J{rr}", f'=IF(OR(G{rr}="",H{rr}=""),"",IF(G{rr}<H{rr}/(1+Spread/2),"Below band",IF(G{rr}>H{rr}/(1+Spread/2)*(1+Spread),"Above band","Within band")))')
    cell(ws, f"N{rr}", f'=IF(M{rr}="","",M{rr}+ExpiryDays)', DATE)
    cell(ws, f"Q{rr}", f'=IF(OR(M{rr}="",P{rr}=""),"",P{rr}-M{rr})', "0")
dv_list(ws, "=RoleList", f"C{OT_START}:C{OT_END}")
dv_list(ws, "=LevelList", f"D{OT_START}:D{OT_END}")
dv_list(ws, "=LocList", f"E{OT_START}:E{OT_END}")
dv_list(ws, "=OfferStatus", f"O{OT_START}:O{OT_END}")
dv_list(ws, "=DeclineList", f"R{OT_START}:R{OT_END}")
ws.conditional_formatting.add(f"J{OT_START}:J{OT_END}", CellIsRule(operator="equal", formula=['"Above band"'], fill=PatternFill("solid", fgColor="FEE2E2")))
ws.conditional_formatting.add(f"J{OT_START}:J{OT_END}", CellIsRule(operator="equal", formula=['"Below band"'], fill=PatternFill("solid", fgColor="FEF3C7")))
ws.conditional_formatting.add(f"O{OT_START}:O{OT_END}", CellIsRule(operator="equal", formula=['"Accepted"'], fill=PatternFill("solid", fgColor="DCFCE7")))
ws.conditional_formatting.add(f"O{OT_START}:O{OT_END}", CellIsRule(operator="equal", formula=['"Declined"'], fill=PatternFill("solid", fgColor="FEE2E2")))
widths(ws, {"A": 16, "B": 9, "C": 30, "D": 7, "E": 34, "F": 9, "G": 15, "H": 15, "I": 11, "J": 13, "K": 12,
            "L": 11, "M": 12, "N": 12, "O": 16, "P": 13, "Q": 10, "R": 16, "S": 26})
ws.freeze_panes = f"B{OT_START}"
ws["A3"] = "Candidate names are placeholders. Store personal data only where your privacy policy allows."
ws["A3"].font = font(size=8, italic=True, color="6B7280")

# ---------------------------------------------------------- Dashboard
ws = S["Dashboard"]
title(ws, "Hiring OS Dashboard - 2026", "Live summary of the Hiring Plan and Offer Tracker. No inputs on this sheet.")
HP, OT = q("Hiring Plan"), q("Offer Tracker")
hp = lambda c: f"{HP}!${c}${HP_START}:${c}${HP_END}"
ot = lambda c: f"{OT}!${c}${OT_START}:${c}${OT_END}"
kpis = [
    ("Total requisitions", f'=COUNTA({hp("A")})', "0"),
    ("Open (not filled)", f'=COUNTA({hp("A")})-COUNTIF({hp("I")},"Filled")', "0"),
    ("Filled", f'=COUNTIF({hp("I")},"Filled")', "0"),
    ("Plan-year hiring cost (USD)", f'=SUM({hp("N")})', USD),
    ("Offers extended", f'=COUNTIF({ot("O")},"Sent")+COUNTIF({ot("O")},"Accepted")+COUNTIF({ot("O")},"Declined")', "0"),
    ("Offer acceptance rate", f'=IFERROR(COUNTIF({ot("O")},"Accepted")/(COUNTIF({ot("O")},"Accepted")+COUNTIF({ot("O")},"Declined")),"-")', PCT0),
    ("Avg compa-ratio (accepted)", f'=IFERROR(AVERAGEIFS({ot("I")},{ot("O")},"Accepted"),"-")', RATIO),
    ("Avg days to decision", f'=IFERROR(AVERAGE({ot("Q")}),"-")', "0.0"),
]
for i, (lab, f_, fmt) in enumerate(kpis):
    col = 2 + (i % 4) * 2
    r0 = 4 + (i // 4) * 3
    a = ws.cell(row=r0, column=col, value=lab)
    a.font = font(size=9, color="6B7280"); a.fill = SUB_FILL
    ws.merge_cells(start_row=r0, start_column=col, end_row=r0, end_column=col + 1)
    v = ws.cell(row=r0 + 1, column=col, value=f_)
    v.font = font(size=18, bold=True, color=NAVY); v.number_format = fmt; v.fill = SUB_FILL
    v.alignment = Alignment(horizontal="left")
    ws.merge_cells(start_row=r0 + 1, start_column=col, end_row=r0 + 1, end_column=col + 1)
    ws.row_dimensions[r0 + 1].height = 30

section(ws, "B11", "Headcount budget by department")
header(ws, 12, 2, ["Department", "Reqs", "Open", "Filled", "Plan-year cost (USD)", "Annual run-rate (USD)"])
for i, dep in enumerate(["Engineering", "Product", "Sales"]):
    rr = 13 + i
    cell(ws, f"B{rr}", dep, bold=True)
    cell(ws, f"C{rr}", f'=COUNTIF({hp("E")},B{rr})', "0")
    cell(ws, f"D{rr}", f'=C{rr}-E{rr}', "0")
    cell(ws, f"E{rr}", f'=COUNTIFS({hp("E")},B{rr},{hp("I")},"Filled")', "0")
    cell(ws, f"F{rr}", f'=SUMIF({hp("E")},B{rr},{hp("N")})', USD)
    cell(ws, f"G{rr}", f'=SUMIF({hp("E")},B{rr},{hp("M")})', USD)
cell(ws, "B16", "Total", bold=True)
for c_ in "CDEFG":
    cell(ws, f"{c_}16", f"=SUM({c_}13:{c_}15)", USD if c_ in "FG" else "0", bold=True)

section(ws, "I11", "Offers by status")
header(ws, 12, 9, ["Status", "Count"])
for i, st in enumerate(["Draft", "Pending approval", "Sent", "Accepted", "Declined", "Rescinded"]):
    rr = 13 + i
    cell(ws, f"I{rr}", st)
    cell(ws, f"J{rr}", f'=COUNTIF({ot("O")},I{rr})', "0")

section(ws, "B20", "Offer quality checks")
checks = [("Offers above band", f'=COUNTIF({ot("J")},"Above band")'),
          ("Offers below band", f'=COUNTIF({ot("J")},"Below band")'),
          ("Offers awaiting approval", f'=COUNTIF({ot("O")},"Pending approval")')]
for i, (lab, f_) in enumerate(checks):
    label(ws, f"B{21+i}", lab); cell(ws, f"C{21+i}", f_, "0", bold=True)

ch = BarChart(); ch.type = "col"; ch.title = "Plan-year hiring cost by department (USD)"
ch.add_data(Reference(ws, min_col=6, min_row=12, max_row=15), titles_from_data=True)
ch.set_categories(Reference(ws, min_col=2, min_row=13, max_row=15))
ch.legend = None; ch.height, ch.width = 7.5, 13; ch.y_axis.numFmt = '#,##0'
ch.y_axis.majorGridlines = None
ch.series[0].graphicalProperties.solidFill = NAVY
ws.add_chart(ch, "B26")
ch2 = BarChart(); ch2.type = "bar"; ch2.title = "Offers by status"
ch2.add_data(Reference(ws, min_col=10, min_row=12, max_row=18), titles_from_data=True)
ch2.set_categories(Reference(ws, min_col=9, min_row=13, max_row=18))
ch2.legend = None; ch2.height, ch2.width = 7.5, 11
ch2.series[0].graphicalProperties.solidFill = TEAL
ws.add_chart(ch2, "I26")
widths(ws, {"A": 2, "B": 18, "C": 14, "D": 14, "E": 18, "F": 18, "G": 20, "H": 4, "I": 18, "J": 12})

# ---------------------------------------------------------- Scorecards
SCALE = [("4", "Strong yes - clearly exceeds the bar with specific evidence"),
         ("3", "Yes - meets the bar for this level"),
         ("2", "No - below the bar, evidence is thin or mixed"),
         ("1", "Strong no - clear concern or red flag")]

def scorecard(ws, fam, role, level, mission, outcomes, musts, comps, scores, interviewers):
    title(ws, f"Role Scorecard - {fam}",
          "Define the bar before interviews start. Interviewers score independently (1-4) before the debrief.")
    info = [("Role", role, "=RoleList"), ("Level", level, "=LevelList"), ("Candidate", "Sample Candidate", None),
            ("Hiring manager", "A. Morgan" if fam == "Engineering" else ("D. Okafor" if fam == "Product" else "P. Novak"), None),
            ("Debrief date", dt.date(2026, 10, 20), None)]
    for i, (lab, v, lst) in enumerate(info):
        rr = 4 + i
        label(ws, f"B{rr}", lab)
        ws.merge_cells(f"C{rr}:D{rr}")
        cell(ws, f"C{rr}", v, DATE if isinstance(v, dt.date) else None, inp=True)
        if lst:
            dv_list(ws, lst, f"C{rr}")
    section(ws, "F3", "Rating scale")
    for i, (n, t) in enumerate(SCALE):
        rr = 4 + i
        cell(ws, f"F{rr}", int(n), bold=True).alignment = CENTER
        ws.merge_cells(f"G{rr}:L{rr}")
        cell(ws, f"G{rr}", t)
    label(ws, "B10", "Mission", bold=True)
    ws.merge_cells("C10:N10"); cell(ws, "C10", mission, inp=True, wrap=True); ws.row_dimensions[10].height = 44
    section(ws, "B12", "Outcomes - what success looks like in the first 12 months")
    for i, o in enumerate(outcomes):
        rr = 13 + i
        cell(ws, f"B{rr}", f"Outcome {i+1}", bold=True)
        ws.merge_cells(f"C{rr}:N{rr}"); cell(ws, f"C{rr}", o, inp=True, wrap=True)
        ws.row_dimensions[rr].height = 30
    section(ws, "B18", "Must-haves (knockout criteria)")
    header(ws, 19, 2, ["#", "Criterion"] + [""] * 8 + ["Met?"])
    ws.merge_cells("C19:K19")
    for i, m in enumerate(musts):
        rr = 20 + i
        cell(ws, f"B{rr}", i + 1)
        ws.merge_cells(f"C{rr}:K{rr}"); cell(ws, f"C{rr}", m, inp=True, wrap=True)
        cell(ws, f"L{rr}", "Yes", inp=True)
        dv_list(ws, "=YesNo", f"L{rr}")
    section(ws, "B24", "Competencies, weights & interviewer scores")
    for j, nm_ in enumerate(interviewers):
        c = cell(ws, f"{'IJKL'[j]}25", nm_, inp=True); c.alignment = CENTER
    label(ws, "H25", "Interviewer ->", bold=True)
    header(ws, 26, 2, ["#", "Code", "Competency", "Weight", 'What a "4" looks like', "Red flags", "Stage",
                       "Int 1", "Int 2", "Int 3", "Int 4", "Avg", "Weighted"])
    C0 = 27
    for i, (code, comp, wgt, good, red, stage) in enumerate(comps):
        rr = C0 + i
        cell(ws, f"B{rr}", i + 1)
        cell(ws, f"C{rr}", code, bold=True)
        cell(ws, f"D{rr}", comp, wrap=True)
        cell(ws, f"E{rr}", wgt, PCT0, inp=True)
        cell(ws, f"F{rr}", good, wrap=True)
        cell(ws, f"G{rr}", red, wrap=True)
        cell(ws, f"H{rr}", stage, wrap=True)
        for j, colx in enumerate("IJKL"):
            v = scores[i][j] if i < len(scores) and scores[i][j] is not None else None
            c = cell(ws, f"{colx}{rr}", v, "0", inp=True); c.alignment = Alignment(horizontal="center", vertical="top")
        dv = DataValidation(type="whole", operator="between", formula1="1", formula2="4", allow_blank=True)
        ws.add_data_validation(dv); dv.add(f"I{rr}:L{rr}")
        cell(ws, f"M{rr}", f'=IF(COUNT(I{rr}:L{rr})=0,"",AVERAGE(I{rr}:L{rr}))', "0.00")
        cell(ws, f"N{rr}", f'=IF(M{rr}="","",M{rr}*E{rr})', "0.00")
        ws.row_dimensions[rr].height = 54
    CE = C0 + len(comps) - 1
    rr = CE + 1
    cell(ws, f"D{rr}", "Total weight", bold=True)
    cell(ws, f"E{rr}", f"=SUM(E{C0}:E{CE})", PCT0, bold=True)
    cell(ws, f"F{rr}", f'=IF(ROUND(E{rr},4)=1,"Weights OK","Weights must total 100%")', bold=True)
    ws.conditional_formatting.add(f"F{rr}", FormulaRule(formula=[f'$F${rr}<>"Weights OK"'], font=Font(name=F, bold=True, color="B91C1C")))
    s0 = rr + 2
    section(ws, f"B{s0}", "Hiring decision")
    label(ws, f"B{s0+1}", "Weighted score (1-4)", bold=True)
    ws.merge_cells(f"C{s0+1}:D{s0+1}")
    cell(ws, f"C{s0+1}", f'=IFERROR(SUM(N{C0}:N{CE})/SUMIFS(E{C0}:E{CE},M{C0}:M{CE},">0"),"")', "0.00", bold=True)
    label(ws, f"B{s0+2}", "Must-haves", bold=True)
    ws.merge_cells(f"C{s0+2}:D{s0+2}")
    cell(ws, f"C{s0+2}", '=IF(COUNTIF(L20:L22,"No")>0,"Not met",IF(COUNTIF(L20:L22,"Yes")=3,"Met","Pending"))', bold=True)
    label(ws, f"B{s0+3}", "Recommendation", bold=True)
    ws.merge_cells(f"C{s0+3}:D{s0+3}")
    rec = (f'=IF(C{s0+1}="","Awaiting scores",IF(C{s0+2}="Not met","No hire - must-have gap",'
           f'IF(C{s0+1}>=3.4,"Strong hire",IF(C{s0+1}>=2.9,"Hire",IF(C{s0+1}>=2.4,"Lean no - discuss","No hire")))))')
    c = cell(ws, f"C{s0+3}", rec, bold=True)
    for txt, color_ in [("Strong hire", "DCFCE7"), ("Hire", "DCFCE7"), ("Lean no - discuss", "FEF3C7")]:
        ws.conditional_formatting.add(f"C{s0+3}", CellIsRule(operator="equal", formula=[f'"{txt}"'], fill=PatternFill("solid", fgColor=color_)))
    ws.conditional_formatting.add(f"C{s0+3}", FormulaRule(formula=[f'LEFT($C${s0+3},7)="No hire"'], fill=PatternFill("solid", fgColor="FEE2E2")))
    ws[f"F{s0+1}"] = "Thresholds: Strong hire >= 3.4 | Hire >= 2.9 | Lean no >= 2.4 | No hire < 2.4. Any must-have marked No overrides the score."
    ws[f"F{s0+1}"].font = font(size=9, color="6B7280")
    ws[f"F{s0+2}"] = "Rows with no scores are excluded from the weighted average. Question IDs refer to Interview_Question_Bank.pdf."
    ws[f"F{s0+2}"].font = font(size=9, color="6B7280")
    label(ws, f"B{s0+5}", "Debrief notes", bold=True)
    ws.merge_cells(f"C{s0+5}:N{s0+7}")
    cell(ws, f"C{s0+5}", "Summarise the evidence behind the decision, open risks and any level adjustment.", inp=True, wrap=True)
    widths(ws, {"A": 2, "B": 15, "C": 9, "D": 26, "E": 8, "F": 40, "G": 32, "H": 14, "I": 9, "J": 9, "K": 9, "L": 9, "M": 7, "N": 9})
    ws.freeze_panes = "A4"

LDR = [("LDR1", "People leadership (managers only)", 0.0,
        "Has grown people into bigger roles; gives direct feedback; builds a team others want to join. Questions LDR1.1-LDR1.6",
        "Takes credit, avoids hard conversations, high regretted attrition", "Manager round"),
       ("LDR2", "Hiring & team building (managers only)", 0.0,
        "Raises the bar with each hire; can describe a hiring mistake and the fix. Questions LDR2.1-LDR2.5",
        "Hires for comfort; vague on how they assess candidates", "Manager round")]

scorecard(S["Scorecard - Engineering"], "Engineering", "Software Engineer", "L3",
    "Design, build and run reliable product features end to end, raising the technical bar of the team through clean code, sound architecture and generous code review.",
    ["Ships at least two customer-facing features from design doc to production with no Sev-1 incidents attributable to the work.",
     "Owns one service or subsystem: on-call ready within 90 days and documents its runbooks.",
     "Reduces a key reliability or performance metric (p95 latency, error rate, build time) by a measurable amount.",
     "Mentors at least one engineer and is a trusted reviewer for the team's main codebase."],
    ["Professional experience shipping and operating production software at the level's scope",
     "Fluent in at least one of the team's primary languages",
     "Authorised to work in the hiring location (or the role is approved for sponsorship)"],
    [("ENG1", "Technical depth", 0.20, "Explains trade-offs in their stack from first principles; knows why, not just how. Questions ENG1.1-ENG1.6", "Buzzwords without depth; can't go one level down", "Technical deep-dive"),
     ("ENG2", "System design", 0.20, "Clarifies requirements, sizes the problem, picks a simple design and evolves it; names failure modes. ENG2.1-ENG2.6", "Jumps to a solution; ignores scale, data or failure", "System design"),
     ("ENG3", "Code quality & craft", 0.15, "Readable, tested, incremental code; talks through edge cases unprompted. ENG3.1-ENG3.5", "No tests, no edge cases, defensive about feedback", "Coding / pairing"),
     ("ENG4", "Debugging & operational excellence", 0.10, "Systematic hypotheses, uses data, writes blameless post-mortems. ENG4.1-ENG4.5", "Guesses randomly; blames others for incidents", "Technical deep-dive"),
     ("ENG5", "Delivery & execution", 0.10, "Breaks work into shippable slices, flags risk early, hits commitments. ENG5.1-ENG5.5", "Big-bang releases; surprises stakeholders late", "Hiring manager"),
     ("CORE1", "Ownership", 0.10, "Owns outcomes beyond their ticket; fixes the root cause. CORE1.1-CORE1.6", '"Not my job"; waits to be told', "Hiring manager"),
     ("CORE2", "Collaboration", 0.10, "Disagrees openly, commits, credits others. CORE2.1-CORE2.6", "Lone wolf; dismissive of other functions", "Cross-functional"),
     ("CORE3", "Communication", 0.05, "Clear, structured, adapts to audience; writes well. CORE3.1-CORE3.5", "Rambling, jargon-heavy, can't summarise", "All rounds")] + LDR,
    [(3, 4, 3, None), (3, 3, 4, None), (4, 3, None, None), (3, None, 3, None), (3, 3, None, None),
     (4, 3, None, None), (3, 4, 3, None), (3, 3, 3, None)],
    ["Interviewer 1", "Interviewer 2", "Interviewer 3", "Interviewer 4"])

scorecard(S["Scorecard - Product"], "Product", "Product Manager", "L3",
    "Own the strategy, roadmap and outcomes for a product area, turning customer insight and data into prioritised bets the team can ship and measure.",
    ["Publishes a 12-month area strategy and roadmap that leadership approves and the team can explain.",
     "Moves the area's north-star metric by an agreed target through shipped experiments or features.",
     "Runs a continuous discovery habit: at least four customer conversations per month, synthesised and shared.",
     "Earns the trust of engineering and design leads, measured by team health survey and peer feedback."],
    ["Has owned a shipped product or feature with measurable outcomes",
     "Comfortable working directly with engineers on technical trade-offs",
     "Authorised to work in the hiring location (or the role is approved for sponsorship)"],
    [("PRD1", "Product sense & customer insight", 0.20, "Starts from a sharp user problem; designs simple, opinionated solutions. PRD1.1-PRD1.6", "Feature lists with no user or problem", "Product sense case"),
     ("PRD2", "Prioritisation & strategy", 0.15, "Clear framework, explicit trade-offs, says no with reasons. PRD2.1-PRD2.6", "Everything is P0; strategy = backlog", "Hiring manager"),
     ("PRD3", "Execution & delivery", 0.15, "Writes crisp specs, de-risks early, ships iteratively. PRD3.1-PRD3.5", "Hands off a spec and disappears", "Execution round"),
     ("PRD4", "Data & experimentation", 0.15, "Defines metrics before building; reads an experiment correctly. PRD4.1-PRD4.6", "Vanity metrics; misreads significance", "Analytics round"),
     ("PRD5", "Technical fluency", 0.10, "Understands architecture well enough to shape scope with engineers. PRD5.1-PRD5.4", "Treats engineering as a black box", "Engineering partner"),
     ("PRD6", "Stakeholder influence", 0.10, "Aligns execs and peers without authority; handles conflict. PRD6.1-PRD6.5", "Escalates everything or avoids conflict", "Cross-functional"),
     ("CORE1", "Ownership", 0.10, "Owns outcomes, not output; closes loops. CORE1.1-CORE1.6", "Blames dependencies for misses", "Hiring manager"),
     ("CORE3", "Communication", 0.05, "Structured narratives, strong writing. CORE3.1-CORE3.5", "Unstructured, can't tell the story", "All rounds")] + LDR,
    [(4, 3, 3, None), (3, 3, None, None), (3, 4, None, None), (2, 3, 3, None), (3, None, 3, None),
     (3, 3, None, None), (3, 3, None, None), (4, 3, 3, None)],
    ["Interviewer 1", "Interviewer 2", "Interviewer 3", "Interviewer 4"])

scorecard(S["Scorecard - Sales"], "Sales", "Account Executive", "L2",
    "Build and close a predictable pipeline of new business in the assigned segment, running disciplined discovery-led sales cycles that create long-term customers.",
    ["Attains at least 100% of ramped annual quota after the ramp period defined in the comp plan.",
     "Maintains pipeline coverage of 3x the quarterly target with accurate CRM hygiene.",
     "Forecast accuracy within +/-10% of commit for each quarter after ramp.",
     "Sources at least 30% of own pipeline through outbound and partner channels."],
    ["Track record of quota attainment in a comparable B2B sales motion",
     "Has run full-cycle deals (discovery to close) in the target deal size",
     "Authorised to work in the hiring location (or the role is approved for sponsorship)"],
    [("SLS1", "Prospecting & pipeline generation", 0.15, "Repeatable outbound system, targeted messaging, owns their number. SLS1.1-SLS1.6", "Relies only on inbound; no system", "Hiring manager"),
     ("SLS2", "Discovery & qualification", 0.20, "Uncovers pain, impact, decision process; disqualifies early. SLS2.1-SLS2.6", "Pitches before asking; happy ears", "Mock discovery call"),
     ("SLS3", "Deal management & closing", 0.20, "Multithreads, builds mutual close plans, protects price. SLS3.1-SLS3.6", "Single-threaded; discounts to close", "Deal review"),
     ("SLS4", "Forecasting & CRM discipline", 0.10, "Forecast is evidence-based and accurate; pipeline is clean. SLS4.1-SLS4.4", "Hope-based forecast; stale CRM", "Deal review"),
     ("SLS5", "Objection handling & negotiation", 0.10, "Stays curious under pressure; trades, never gives. SLS5.1-SLS5.5", "Caves on price; argues with buyer", "Mock discovery call"),
     ("SLS6", "Resilience & coachability", 0.10, "Learns from losses, seeks feedback, applies it in-round. SLS6.1-SLS6.5", "Blames territory/product; ignores coaching", "All rounds"),
     ("CORE3", "Communication", 0.10, "Concise, confident, tailors to buyer persona. CORE3.1-CORE3.5", "Talks over buyer; generic pitch", "All rounds"),
     ("CORE2", "Collaboration", 0.05, "Partners with SEs, CS and product; shares credit. CORE2.1-CORE2.6", "Lone wolf; throws deals over the wall", "Cross-functional")] + LDR,
    [(3, 3, None, None), (4, 3, 4, None), (3, 3, None, None), (3, 2, None, None), (3, 3, 3, None),
     (4, 4, None, None), (3, 3, 3, None), (3, None, None, None)],
    ["Interviewer 1", "Interviewer 2", "Interviewer 3", "Interviewer 4"])

# ---------------------------------------------------------- Interview Loops
ws = S["Interview Loops"]
title(ws, "Structured Interview Loops", "Recommended loop per family. Question IDs map to Interview_Question_Bank.pdf.")
loops = {
    "Engineering": [
        ("Recruiter screen", "30 min", "Recruiter", "Video", "Motivation, logistics, comp alignment", "CORE1.1, CORE3.1", "Clear motivation; band aligned"),
        ("Hiring manager screen", "45 min", "Hiring manager", "Video", "Ownership, delivery, past scope", "ENG5.1-5.3, CORE1.2", "Scope matches level"),
        ("Coding / pairing", "60 min", "Senior engineer", "Live pairing in own IDE", "Code quality & craft", "ENG3.1-3.5 + exercise rubric", "Working, tested, readable solution"),
        ("System design", "60 min", "Staff engineer", "Whiteboard / doc", "System design", "ENG2.1-2.6 (pick 1 prompt)", "Score >= 3"),
        ("Technical deep-dive", "60 min", "Senior engineer", "Past project walkthrough", "Technical depth, debugging", "ENG1.1-1.6, ENG4.1-4.5", "Score >= 3 on both"),
        ("Cross-functional", "45 min", "PM or designer", "Behavioural", "Collaboration, communication", "CORE2.1-2.6, CORE3.2-3.5", "No red flags"),
        ("Debrief", "30 min", "All interviewers + HM", "Meeting", "Decision", "Scorecard - Engineering", "Weighted score >= 2.9"),
    ],
    "Product": [
        ("Recruiter screen", "30 min", "Recruiter", "Video", "Motivation, logistics, comp alignment", "CORE1.1, CORE3.1", "Clear motivation; band aligned"),
        ("Hiring manager screen", "45 min", "Hiring manager", "Video", "Strategy, ownership", "PRD2.1-2.3, CORE1.2", "Scope matches level"),
        ("Product sense case", "60 min", "Senior PM", "Live case", "Product sense & customer insight", "PRD1.1-1.6 (pick 1 case)", "Score >= 3"),
        ("Analytics round", "45 min", "Data scientist", "Metrics case", "Data & experimentation", "PRD4.1-4.6", "Score >= 3"),
        ("Execution round", "45 min", "Engineering lead", "Behavioural + scenario", "Execution, technical fluency", "PRD3.1-3.5, PRD5.1-5.4", "No red flags"),
        ("Stakeholder round", "45 min", "Design or sales lead", "Behavioural", "Influence, communication", "PRD6.1-6.5, CORE3.2", "No red flags"),
        ("Debrief", "30 min", "All interviewers + HM", "Meeting", "Decision", "Scorecard - Product", "Weighted score >= 2.9"),
    ],
    "Sales": [
        ("Recruiter screen", "30 min", "Recruiter", "Phone / video", "Motivation, quota history, OTE alignment", "SLS6.1, SLS1.1", "Verifiable attainment"),
        ("Hiring manager screen", "45 min", "Sales manager", "Video", "Pipeline generation, attainment", "SLS1.2-1.6, SLS4.1", "Clear, repeatable system"),
        ("Mock discovery call", "45 min", "Sales manager + SE", "Role-play (brief in PDF)", "Discovery, objection handling", "SLS2, SLS5 + role-play rubric", "Score >= 3 on discovery"),
        ("Deal review", "45 min", "Senior AE / VP", "Walk through a closed-won and closed-lost deal", "Deal management, forecasting", "SLS3.1-3.6, SLS4.2-4.4", "Score >= 3"),
        ("Cross-functional", "30 min", "CS or SE lead", "Behavioural", "Collaboration, coachability", "CORE2.1-2.4, SLS6.2-6.5", "No red flags"),
        ("Reference checks", "2 x 20 min", "Hiring manager", "Phone", "Validate attainment & coachability", "Reference guide in PDF", "Consistent with interviews"),
        ("Debrief", "30 min", "All interviewers + HM", "Meeting", "Decision", "Scorecard - Sales", "Weighted score >= 2.9"),
    ],
}
r = 4
for fam, stages_ in loops.items():
    section(ws, f"A{r}", f"{fam} loop")
    header(ws, r + 1, 1, ["#", "Stage", "Duration", "Interviewer", "Format", "Competencies assessed", "Question bank IDs", "Pass bar"])
    for i, st in enumerate(stages_):
        rr = r + 2 + i
        cell(ws, f"A{rr}", i + 1)
        for j, v in enumerate(st):
            cell(ws, f"{'BCDEFGH'[j]}{rr}", v, inp=True, wrap=True)
    r = r + 2 + len(stages_) + 2
section(ws, f"A{r}", "Process SLAs")
header(ws, r + 1, 1, ["#", "Commitment", "Target"])
slas = [("Feedback submitted after each interview", "Within 24 hours, before seeing others' scores"),
        ("Candidate told the outcome of each stage", "Within 2 business days"),
        ("Application to offer", "21 days or fewer"),
        ("Verbal offer to written offer", "Same day"),
        ("Rejected candidates receive a personal note", "After any onsite / final round")]
for i, (a, b) in enumerate(slas):
    rr = r + 2 + i
    cell(ws, f"A{rr}", i + 1); cell(ws, f"B{rr}", a, inp=True); cell(ws, f"C{rr}", b, inp=True)
widths(ws, {"A": 5, "B": 34, "C": 32, "D": 22, "E": 24, "F": 32, "G": 30, "H": 26})

# ---------------------------------------------------------- Offer Generator
ws = S["Offer Generator"]
title(ws, "Automated Offer Letter Generator",
      "Fill the yellow inputs. The merge fields and the letter preview update instantly. Paste values into Offer_Templates.docx or use Word Mail Merge.")
section(ws, "B3", "1. Offer inputs")
og_in = [
    ("Candidate full name", "Jordan Rivera", None, None),
    ("Role", "Software Engineer", None, "=RoleList"),
    ("Level", "L3", None, "=LevelList"),
    ("Work location", "US Tier 2 - Boston / LA / Austin / DC", None, "=LocList"),
    ("Employment type", "full-time, exempt", None, None),
    ("Start date", dt.date(2026, 12, 7), DATE, None),
    ("Reporting manager", "Alex Morgan", None, None),
    ("Manager title", "Director of Engineering", None, None),
    ("Base salary (local, annual)", 186000, USD, None),
    ("Sign-on bonus (local)", 10000, USD, None),
    ("Equity units offered", 64000, "#,##0", None),
    ("Equity type", "stock options", None, "=EquityTypeList"),
    ("Offer date", dt.date(2026, 10, 22), DATE, None),
    ("Signatory name", "Sam Lee", None, None),
    ("Signatory title", "Chief Executive Officer", None, None),
]
for i, (lab, v, fmt, lst) in enumerate(og_in):
    rr = 4 + i
    label(ws, f"B{rr}", lab)
    cell(ws, f"C{rr}", v, fmt, inp=True)
    if lst:
        dv_list(ws, lst, f"C{rr}")
# C4 name, C5 role, C6 level, C7 loc, C8 type, C9 start, C10 mgr, C11 mgr title, C12 base, C13 signon, C14 units, C15 eq type, C16 offer date, C17 sig, C18 sig title
OK = '$C$5&"|"&$C$6'
section(ws, "B20", "2. Calculated terms")
og_calc = [
    ("Job title", f'=IFERROR({bm("BM_Title", OK)},"Level not offered for role")', None),            # 21
    ("Department", f'=IFERROR({bm("BM_Family", OK)},"")', None),                                     # 22
    ("Currency", f'=IFERROR({loc("LocCcy", "$C$7")},"")', None),                                     # 23
    ("Band midpoint (local)", f'=IFERROR({bm("BM_P50", OK)}*{loc("LocGeo", "$C$7")}*{loc("LocFX", "$C$7")}*CashFactor*Positioning,"")', USD),  # 24
    ("Band minimum (local)", '=IFERROR(C24/(1+Spread/2),"")', USD),                                  # 25
    ("Band maximum (local)", '=IFERROR(C25*(1+Spread),"")', USD),                                    # 26
    ("Compa-ratio", '=IFERROR(C12/C24,"")', RATIO),                                                   # 27
    ("Band status", '=IF(C24="","",IF(C12<C25,"Below band",IF(C12>C26,"Above band","Within band")))', None),  # 28
    ("Target bonus %", f'=IFERROR({bm("BM_Bonus", OK)},0)', PCT0),                                   # 29
    ("Target bonus (local)", '=C12*C29', USD),                                                        # 30
    ("Sales role?", f'=IFERROR(IF({bm("BM_BaseShare", OK)}<1,"Yes","No"),"No")', None),             # 31
    ("On-target earnings (local)", f'=IF(C31="Yes",C12/{bm("BM_BaseShare", OK)},C12)', USD),         # 32
    ("Variable at target (local)", '=C32-C12', USD),                                                  # 33
    ("Guideline equity units", f'=IFERROR(ROUND(C12/{loc("LocFX", "$C$7")}*{bm("BM_Equity", OK)}*EquityFactor*4/SharePrice,-2),0)', "#,##0"),  # 34
    ("Equity grant value (USD, 4 yrs)", '=C14*SharePrice', '$#,##0'),                                 # 35
    ("Offer expiry date", '=C16+ExpiryDays', DATE),                                                   # 36
    ("Year-1 total comp (local)", f'=C12+C30+C33+C13+IFERROR(C35/4*{loc("LocFX", "$C$7")},0)', USD),  # 37
    ("Flag: above band", '=IF(C28="Above band","Yes","No")', None),                                    # 38
    ("Flag: sign-on over threshold", '=IF(C13>C12*SignOnThreshold,"Yes","No")', None),                # 39
    ("Flag: equity over guideline", '=IF(AND(C34>0,C14>C34*EquityThreshold),"Yes","No")', None),       # 40
    ("Approval route", '=IF(OR(C38="Yes",C39="Yes",C40="Yes"),"Exception: VP + Finance sign-off (Offer Approval Form)","Standard: Hiring manager + Recruiting lead")', None),  # 41
]
for i, (lab, f_, fmt) in enumerate(og_calc):
    rr = 21 + i
    label(ws, f"B{rr}", lab)
    cell(ws, f"C{rr}", f_, fmt, bold=lab in ("Band status", "Approval route"))
ws.conditional_formatting.add("C41", FormulaRule(formula=['LEFT($C$41,9)="Exception"'], fill=PatternFill("solid", fgColor="FEE2E2"), font=Font(name=F, bold=True, color="B91C1C")))
ws.conditional_formatting.add("C38:C40", CellIsRule(operator="equal", formula=['"Yes"'], font=Font(name=F, bold=True, color="B91C1C")))

section(ws, "E3", "3. Merge fields (match the {{TOKENS}} in Offer_Templates.docx)")
header(ws, 4, 5, ["Token", "Value"])
M = lambda x: f'$C$23&" "&TEXT({x},"#,##0")'
tokens = [
    ("{{COMPANY_NAME}}", "=CompanyName"),
    ("{{CANDIDATE_NAME}}", "=$C$4"),
    ("{{CANDIDATE_FIRST_NAME}}", '=LEFT($C$4,FIND(" ",$C$4&" ")-1)'),
    ("{{JOB_TITLE}}", "=$C$21"),
    ("{{LEVEL}}", "=$C$6"),
    ("{{DEPARTMENT}}", "=$C$22"),
    ("{{WORK_LOCATION}}", "=$C$7"),
    ("{{EMPLOYMENT_TYPE}}", "=$C$8"),
    ("{{START_DATE}}", '=TEXT($C$9,"mmmm d, yyyy")'),
    ("{{MANAGER_NAME}}", "=$C$10"),
    ("{{MANAGER_TITLE}}", "=$C$11"),
    ("{{CURRENCY}}", "=$C$23"),
    ("{{BASE_SALARY}}", "=" + M("$C$12")),
    ("{{PAY_FREQUENCY}}", "=PayFreq"),
    ("{{BONUS_TARGET_PCT}}", '=TEXT($C$29,"0%")'),
    ("{{BONUS_TARGET_AMOUNT}}", "=" + M("$C$30")),
    ("{{OTE}}", "=" + M("$C$32")),
    ("{{VARIABLE_TARGET}}", "=" + M("$C$33")),
    ("{{SIGN_ON_BONUS}}", "=" + M("$C$13")),
    ("{{EQUITY_UNITS}}", '=TEXT($C$14,"#,##0")'),
    ("{{EQUITY_TYPE}}", "=$C$15"),
    ("{{VESTING_SCHEDULE}}", "=Vesting"),
    ("{{OFFER_DATE}}", '=TEXT($C$16,"mmmm d, yyyy")'),
    ("{{OFFER_EXPIRY_DATE}}", '=TEXT($C$36,"mmmm d, yyyy")'),
    ("{{SIGNATORY_NAME}}", "=$C$17"),
    ("{{SIGNATORY_TITLE}}", "=$C$18"),
]
for i, (tok, f_) in enumerate(tokens):
    rr = 5 + i
    cell(ws, f"E{rr}", tok, color="6B7280")
    cell(ws, f"F{rr}", f_)

P0 = 45
section(ws, f"B{P0-1}", "4. Letter preview (auto-generated - copy into your letterhead or use the Word template)")
paras = [
    ('=CompanyName', True),
    ('=TEXT($C$16,"mmmm d, yyyy")', False),
    ('="Dear "&$F$7&","', False),
    ('="On behalf of "&CompanyName&", I am delighted to offer you the position of "&$C$21&" ("&$C$6&") on our "&$C$22&" team, reporting to "&$C$10&", "&$C$11&". This is a "&$C$8&" position based in "&$C$7&", with an anticipated start date of "&$F$13&"."', False),
    ('="Base salary. Your starting base salary will be "&$F$17&" per year, paid "&PayFreq&" in line with our standard payroll practices and subject to applicable withholdings."', False),
    ('=IF($C$31="Yes","Variable compensation. You will be eligible for variable compensation with an annual on-target amount of "&$F$22&", for total on-target earnings (OTE) of "&$F$21&". Commission terms are governed by the sales compensation plan you will receive separately.",IF($C$29>0,"Annual bonus. You will be eligible for an annual target bonus of "&$F$19&" of base salary ("&$F$20&"), based on company and individual performance and the terms of the bonus plan.","Annual bonus. This role is not currently part of an annual bonus program."))', False),
    ('=IF($C$13>0,"Sign-on bonus. You will receive a one-time sign-on bonus of "&$F$23&", paid with your first regular paycheck. If you resign or are terminated for cause within 12 months of your start date, you agree to repay a pro-rated portion.","")', False),
    ('=IF($C$14>0,"Equity. Subject to approval by the Board of Directors, you will be granted "&$F$24&" "&$C$15&", vesting over "&Vesting&", under the terms of the company\'s equity incentive plan and your grant agreement.","")', False),
    ('="Benefits. You will be eligible to participate in the benefit programs "&CompanyName&" makes available to similarly situated employees, subject to the terms of those plans, which may change from time to time."', False),
    ('=IF($C$23="USD","Your employment with "&CompanyName&" is at-will, meaning either you or the company may end it at any time, with or without cause or notice. This offer is contingent on satisfactory completion of a background check, verification of your eligibility to work, and signing our standard confidentiality and invention assignment agreement.","Your employment will be governed by a written employment agreement that complies with local law in "&$C$7&", including probation and notice terms. This offer is contingent on verification of your right to work and signing our standard confidentiality and intellectual property agreement.")', False),
    ('="This offer will remain open until "&$F$28&". We are excited about what we can build together and look forward to welcoming you to the team."', False),
    ('="Sincerely,"', False),
    ('=$C$17&", "&$C$18&", "&CompanyName', True),
]
for i, (f_, b) in enumerate(paras):
    rr = P0 + i
    ws.merge_cells(f"B{rr}:F{rr}")
    c = ws[f"B{rr}"]
    c.value = f_
    c.font = font(bold=b, size=10)
    c.alignment = Alignment(wrap_text=True, vertical="top")
    ln = 1 if b or i in (1, 2, 11) else 4
    ws.row_dimensions[rr].height = 32 if ln > 1 else 18
ws.row_dimensions[P0 + 3].height = 48
ws.row_dimensions[P0 + 5].height = 34
ws.row_dimensions[P0 + 9].height = 48
ws.row_dimensions[P0 + 6].height = 40
ws.row_dimensions[P0 + 7].height = 40
for rr in range(P0, P0 + len(paras)):
    for cc in "BCDEF":
        ws[f"{cc}{rr}"].fill = PatternFill("solid", fgColor="FFFFFF")
widths(ws, {"A": 2, "B": 32, "C": 40, "D": 3, "E": 26, "F": 34, "G": 14, "H": 14, "I": 14, "J": 14})

# ---------------------------------------------------------- Onboarding
ws = S["Onboarding 30-60-90"]
title(ws, "New Employee 30-60-90 Day Onboarding Plan",
      "Pick the role family and start date. Tasks for other families grey out; due dates and progress calculate automatically.")
ob_in = [("New hire", "Jordan Rivera"), ("Role family", "Engineering"), ("Start date", dt.date(2026, 12, 7)),
         ("Manager", "Alex Morgan"), ("Onboarding buddy", "Casey Kim")]
for i, (lab, v) in enumerate(ob_in):
    rr = 4 + i
    label(ws, f"B{rr}", lab)
    cell(ws, f"C{rr}", v, DATE if isinstance(v, dt.date) else None, inp=True)
dv_list(ws, "=FamilyList", "C5")
header(ws, 3, 6, ["Phase", "Tasks", "Done", "Progress"])
tasks = [
    ("Pre-boarding", "All", "Send welcome email with first-week agenda and buddy intro", "Do", "Manager", -7),
    ("Pre-boarding", "All", "Order laptop, accounts (email, SSO, chat, HRIS) and ship equipment", "Do", "IT", -7),
    ("Pre-boarding", "All", "Complete payroll, tax, right-to-work and benefits paperwork", "Do", "New hire", -3),
    ("Pre-boarding", "All", "Share the 30-60-90 plan and role scorecard outcomes", "Do", "Manager", -2),
    ("Pre-boarding", "Engineering", "Grant repo, CI/CD, cloud console and observability access", "Do", "IT", -1),
    ("Pre-boarding", "Sales", "Provision CRM, sales engagement and call-recording seats", "Do", "IT", -1),
    ("Days 1-30", "All", "Day 1: welcome, team lunch, workstation and tools check", "Meet", "Manager", 0),
    ("Days 1-30", "All", "Company overview: mission, strategy, customers, values", "Learn", "People", 1),
    ("Days 1-30", "All", "Complete security, privacy and code-of-conduct training", "Learn", "New hire", 5),
    ("Days 1-30", "All", "1:1s with each direct teammate and key cross-functional partners", "Meet", "New hire", 10),
    ("Days 1-30", "All", "Agree 90-day goals with manager (written, measurable)", "Do", "Manager", 7),
    ("Days 1-30", "All", "Weekly 1:1 with manager established", "Meet", "Manager", 3),
    ("Days 1-30", "Engineering", "Set up local dev environment; ship a first small PR to production", "Deliver", "New hire", 5),
    ("Days 1-30", "Engineering", "Architecture walkthrough of core services with a senior engineer", "Learn", "Buddy", 7),
    ("Days 1-30", "Engineering", "Shadow one on-call rotation and read the top 5 runbooks", "Learn", "New hire", 21),
    ("Days 1-30", "Engineering", "Fix 3 starter bugs or tech-debt tickets", "Deliver", "New hire", 25),
    ("Days 1-30", "Product", "Product deep-dive: use every core flow as a customer", "Learn", "New hire", 5),
    ("Days 1-30", "Product", "Review metrics dashboards, roadmap and last 3 months of research", "Learn", "Manager", 10),
    ("Days 1-30", "Product", "Join or run 4+ customer conversations", "Meet", "New hire", 25),
    ("Days 1-30", "Product", "Write a 'first impressions' memo: opportunities and open questions", "Deliver", "New hire", 28),
    ("Days 1-30", "Sales", "Complete product and ICP certification", "Learn", "Sales enablement", 10),
    ("Days 1-30", "Sales", "Shadow 10+ calls across discovery, demo and negotiation stages", "Learn", "Buddy", 15),
    ("Days 1-30", "Sales", "Pass mock discovery call and pitch certification", "Deliver", "Manager", 21),
    ("Days 1-30", "Sales", "Build territory plan and target account list", "Deliver", "New hire", 28),
    ("Days 1-30", "All", "Day-30 check-in: what is working, what is blocking, goal review", "Checkpoint", "Manager", 30),
    ("Days 31-60", "All", "Take ownership of first defined area or set of accounts", "Do", "New hire", 35),
    ("Days 31-60", "All", "Present learnings and early ideas at a team meeting", "Deliver", "New hire", 45),
    ("Days 31-60", "All", "Gather informal feedback from 3 peers", "Meet", "Manager", 50),
    ("Days 31-60", "Engineering", "Lead a small feature end to end (design note, build, ship)", "Deliver", "New hire", 55),
    ("Days 31-60", "Engineering", "Join on-call rotation as secondary", "Do", "New hire", 45),
    ("Days 31-60", "Engineering", "Perform 10+ code reviews for the team", "Do", "New hire", 60),
    ("Days 31-60", "Product", "Own the backlog for one squad; run planning and refinement", "Do", "New hire", 40),
    ("Days 31-60", "Product", "Ship first experiment or improvement with success metrics defined", "Deliver", "New hire", 60),
    ("Days 31-60", "Sales", "Run full discovery calls independently; 15+ qualified meetings", "Do", "New hire", 50),
    ("Days 31-60", "Sales", "Build pipeline to 1.5x ramp target", "Deliver", "New hire", 60),
    ("Days 31-60", "Sales", "Weekly deal reviews with manager; CRM hygiene at 100%", "Do", "Manager", 45),
    ("Days 31-60", "All", "Day-60 check-in: progress against 90-day goals", "Checkpoint", "Manager", 60),
    ("Days 61-90", "All", "Operate independently in the role's core responsibilities", "Do", "New hire", 75),
    ("Days 61-90", "All", "Propose one process or product improvement with a written rationale", "Deliver", "New hire", 80),
    ("Days 61-90", "All", "Set goals for the next quarter with manager", "Do", "Manager", 85),
    ("Days 61-90", "Engineering", "Primary on-call shift completed", "Do", "New hire", 75),
    ("Days 61-90", "Engineering", "Own a service or subsystem; document its runbook", "Deliver", "New hire", 90),
    ("Days 61-90", "Product", "Publish area strategy draft and 2-quarter roadmap", "Deliver", "New hire", 85),
    ("Days 61-90", "Product", "Present results of first shipped experiment", "Deliver", "New hire", 90),
    ("Days 61-90", "Sales", "Pipeline at 3x quarterly ramp target; first deal(s) closed or in commit", "Deliver", "New hire", 85),
    ("Days 61-90", "Sales", "Forecast submitted with evidence for each commit deal", "Do", "New hire", 90),
    ("Days 61-90", "All", "Day-90 review: written feedback both ways and onboarding survey", "Checkpoint", "Manager", 90),
]
OB_HDR = 11
header(ws, OB_HDR, 1, ["#", "Phase", "Track", "Task / goal", "Type", "Owner", "Due (day)", "Due date", "Applies?", "Status", "Notes"])
OB0 = OB_HDR + 1
sample_status = {0: "Done", 1: "Done", 2: "Done", 3: "Done", 4: "Done", 6: "In progress"}
for i, (ph, tr, tk, ty, ow, day) in enumerate(tasks):
    rr = OB0 + i
    cell(ws, f"A{rr}", i + 1)
    cell(ws, f"B{rr}", ph, inp=True); cell(ws, f"C{rr}", tr, inp=True)
    cell(ws, f"D{rr}", tk, inp=True, wrap=True); cell(ws, f"E{rr}", ty, inp=True)
    cell(ws, f"F{rr}", ow, inp=True); cell(ws, f"G{rr}", day, "0", inp=True)
    cell(ws, f"H{rr}", f'=IF(I{rr}="Yes",$C$6+G{rr},"")', DATE)
    cell(ws, f"I{rr}", f'=IF(OR(C{rr}="All",C{rr}=$C$5),"Yes","No")')
    cell(ws, f"J{rr}", sample_status.get(i, "Not started"), inp=True)
    cell(ws, f"K{rr}", None, inp=True)
OBE = OB0 + len(tasks) + 15  # spare rows for custom tasks
for rr in range(OB0 + len(tasks), OBE + 1):
    cell(ws, f"A{rr}", rr - OB0 + 1)
    for c_ in "BCDEFGJK":
        cell(ws, f"{c_}{rr}", None, "0" if c_ == "G" else None, inp=True)
    cell(ws, f"H{rr}", f'=IF(AND(I{rr}="Yes",G{rr}<>""),$C$6+G{rr},"")', DATE)
    cell(ws, f"I{rr}", f'=IF(D{rr}="","",IF(OR(C{rr}="All",C{rr}=$C$5),"Yes","No"))')
dv_list(ws, '"Pre-boarding,Days 1-30,Days 31-60,Days 61-90"', f"B{OB0}:B{OBE}")
dv_list(ws, '"All,Engineering,Product,Sales"', f"C{OB0}:C{OBE}")
dv_list(ws, "=TaskStatus", f"J{OB0}:J{OBE}")
for i, ph in enumerate(["Pre-boarding", "Days 1-30", "Days 31-60", "Days 61-90", "Total"]):
    rr = 4 + i
    cell(ws, f"F{rr}", ph, bold=True)
    if ph == "Total":
        cell(ws, f"G{rr}", "=SUM(G4:G7)", "0", bold=True)
        cell(ws, f"H{rr}", "=SUM(H4:H7)", "0", bold=True)
    else:
        cell(ws, f"G{rr}", f'=COUNTIFS($B${OB0}:$B${OBE},F{rr},$I${OB0}:$I${OBE},"Yes")', "0")
        cell(ws, f"H{rr}", f'=COUNTIFS($B${OB0}:$B${OBE},F{rr},$I${OB0}:$I${OBE},"Yes",$J${OB0}:$J${OBE},"Done")', "0")
    cell(ws, f"I{rr}", f"=IFERROR(H{rr}/G{rr},0)", PCT0, bold=(ph == "Total"))
from openpyxl.formatting.rule import DataBarRule
ws.conditional_formatting.add("I4:I8", DataBarRule(start_type="num", start_value=0, end_type="num", end_value=1, color="0F766E"))
ws.conditional_formatting.add(f"A{OB0}:K{OBE}", FormulaRule(formula=[f'$I{OB0}="No"'], font=Font(name=F, color="BFBFBF")))
ws.conditional_formatting.add(f"J{OB0}:J{OBE}", CellIsRule(operator="equal", formula=['"Done"'], fill=PatternFill("solid", fgColor="DCFCE7")))
ws.conditional_formatting.add(f"J{OB0}:J{OBE}", CellIsRule(operator="equal", formula=['"Blocked"'], fill=PatternFill("solid", fgColor="FEE2E2")))
ws.conditional_formatting.add(f"A{OB0}:K{OBE}", FormulaRule(formula=[f'$E{OB0}="Checkpoint"'], fill=PatternFill("solid", fgColor="EEF2F7")))
widths(ws, {"A": 5, "B": 18, "C": 13, "D": 58, "E": 11, "F": 16, "G": 9, "H": 13, "I": 10, "J": 13, "K": 28})
ws.freeze_panes = f"A{OB0}"

# ---------------------------------------------------------- README
ws = S["README"]
title(ws, "Tech Hiring & Compensation Benchmark OS - 2026",
      "Structured scorecards, interview loops, global comp bands, an offer generator and onboarding in one workbook.")
section(ws, "B4", "Quick start")
steps = [
    "1. Settings: enter your company name, stage, positioning, price per share and FX rates.",
    "2. Salary Benchmarks: replace the illustrative market data with your survey cut (blue cells).",
    "3. Hiring Plan: add requisitions. Budgets are priced from the band midpoint for each location.",
    "4. Scorecards: edit mission, outcomes and weights before the first interview. Interviewers score 1-4.",
    "5. Interview Loops: confirm stages and interviewers; question IDs map to Interview_Question_Bank.pdf.",
    "6. Band Calculator: sanity-check any number before you share it with a candidate.",
    "7. Offer Generator: fill the inputs, check the approval route, then copy merge fields into Offer_Templates.docx.",
    "8. Offer Tracker + Onboarding 30-60-90: log every offer and run the new hire's first 90 days.",
]
for i, s_ in enumerate(steps):
    ws[f"B{5+i}"] = s_
    ws[f"B{5+i}"].font = font()
section(ws, "B14", "Sheet guide")
header(ws, 15, 2, ["Sheet", "What it does"])
guide = [
    ("Dashboard", "KPIs, budget by department, offer funnel and quality checks"),
    ("Hiring Plan", "Requisitions with auto-priced budget and plan-year proration"),
    ("Band Calculator", "Single offer check: band, compa-ratio, OTE, equity guideline, total comp"),
    ("Comp Bands", "Full band table for every role and level, re-priced for any location"),
    ("Salary Benchmarks", "Market P25 / P50 / P75 by role and level (US Tier 1 reference, USD)"),
    ("Scorecard - Engineering / Product / Sales", "Mission, outcomes, must-haves, weighted competencies, auto recommendation"),
    ("Interview Loops", "Stage-by-stage loop per family with question bank IDs and pass bars"),
    ("Offer Generator", "Offer terms, approval flags, {{merge fields}} and an auto-written letter preview"),
    ("Offer Tracker", "Offer log with band status, expiry and time-to-decision"),
    ("Onboarding 30-60-90", "Role-aware onboarding plan with due dates and progress"),
    ("Settings", "Global inputs, stage factors, locations/FX, dropdown lists"),
]
for i, (a, b) in enumerate(guide):
    cell(ws, f"B{16+i}", a, bold=True); cell(ws, f"C{16+i}", b)
r0 = 16 + len(guide) + 1
section(ws, f"B{r0}", "Colour legend")
cell(ws, f"B{r0+1}", "Blue text, yellow fill", inp=True); cell(ws, f"C{r0+1}", "Input - safe to edit")
cell(ws, f"B{r0+2}", "Black text"); cell(ws, f"C{r0+2}", "Formula - do not overwrite")
cell(ws, f"B{r0+3}", "Green text", link=True); cell(ws, f"C{r0+3}", "Link pulled from another sheet")
r1 = r0 + 5
section(ws, f"B{r1}", "How the numbers work")
how = [
    "Local band midpoint = Market P50 (USD) x geo multiplier x FX x stage cash factor x positioning.",
    "Band min = midpoint / (1 + spread / 2); band max = min x (1 + spread). Default spread is 40%.",
    "Sales benchmarks are base salary. OTE = base / base share of OTE.",
    "Equity guideline (annual) = base x equity % x stage equity factor; units = 4-year value / price per share.",
    "Plan-year cost prorates the loaded annual cost from the target start month.",
]
for i, h in enumerate(how):
    ws[f"B{r1+1+i}"] = h; ws[f"B{r1+1+i}"].font = font()
r2 = r1 + len(how) + 2
section(ws, f"B{r2}", "Important notes")
notes = [
    "All market data, FX rates and employer-cost loads are illustrative 2026 planning estimates, not survey results or quotes.",
    "Sample names, requisitions and offers are fictional. Clear them before use.",
    "Works in Excel, Google Sheets and LibreOffice (standard functions only: INDEX, MATCH, SUMIFS, COUNTIFS, TEXT).",
    "Planning and process template only. Not legal, tax or financial advice. Have counsel review offer terms and pay-transparency obligations.",
]
for i, n in enumerate(notes):
    ws[f"B{r2+1+i}"] = n; ws[f"B{r2+1+i}"].font = font(size=9, color="374151")
widths(ws, {"A": 2, "B": 44, "C": 80})

for w in wb.worksheets:
    w.sheet_properties.pageSetUpPr.fitToPage = True
    w.page_setup.orientation = "landscape"
    w.page_setup.fitToWidth = 1
    w.page_setup.fitToHeight = 0
S["README"].sheet_properties.tabColor = NAVY
S["Dashboard"].sheet_properties.tabColor = TEAL
for n in ("Scorecard - Engineering", "Scorecard - Product", "Scorecard - Sales", "Interview Loops"):
    S[n].sheet_properties.tabColor = "6366F1"
for n in ("Offer Generator", "Offer Tracker"):
    S[n].sheet_properties.tabColor = "D97706"
S["Settings"].sheet_properties.tabColor = "6B7280"
wb.properties.creator = "Tech Hiring OS"
wb.properties.title = "Tech Hiring & Compensation Benchmark OS 2026"
wb.save(OUT)
print("saved", OUT)
